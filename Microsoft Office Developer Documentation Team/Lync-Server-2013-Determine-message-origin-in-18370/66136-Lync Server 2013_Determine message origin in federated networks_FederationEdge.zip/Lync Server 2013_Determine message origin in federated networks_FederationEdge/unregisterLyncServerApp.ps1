remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/FederationEdge"

del 'C:\Program Files\Microsoft Lync server 2013\server\Core\FederationEdge.am'

invoke-csManagementStoreReplication

