copy FederationEdge.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.microsoft.com/LC/SDK/Samples/FederationEdge" -identity "service:registrar:<lync-sever-fqdn>/FederationEdge" -critical $false -priority 5 -scriptname FederationEdge.am -enabled $true

invoke-csManagementStoreReplication