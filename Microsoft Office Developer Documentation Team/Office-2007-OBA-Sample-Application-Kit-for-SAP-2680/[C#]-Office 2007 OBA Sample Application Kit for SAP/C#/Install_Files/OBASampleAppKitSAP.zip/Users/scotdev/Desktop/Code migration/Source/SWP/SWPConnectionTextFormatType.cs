using System;

namespace SoftwarePronto.CodeGenerator.DatabaseDriverCommon
{
    public enum SWPConnectionTextFormatType
    {
        ConnectionName,
        ConnectionString
    }
}
