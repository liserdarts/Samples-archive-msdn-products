using System;
using System.Data.SqlClient;

namespace Microsoft.SAPSK.ContosoTours.DAL
{
    public partial class SAPDataLimits
    {
    }
}