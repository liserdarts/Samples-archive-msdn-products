using System;
using System.Data;
using System.Text;

using SoftwarePronto.CodeGenerator.DatabaseDriverCommon;


namespace Microsoft.SAPSK.ContosoTours.DAL
{
    public partial class SAPActorEventReadOnly : SWPDataReadOnlyBase
    {
    }
}

