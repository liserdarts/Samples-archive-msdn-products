using System;
using System.Data;
using System.Text;
using System.Data.Common;



namespace Microsoft.SAPSK.ContosoTours.DAL
{
    public partial class SAPVenueReadWrite
    {

    }
}

