Context Channel Sample Application:
UCMA application - BasicAVCall.zip
Lync application - ContextualCommunication.zip
Reg export file - ContextualCommunication.reg


The HTML, logo, and .xap files for the Micrsoft Lync 2010 application are in wwwroot*.zip. These files must be available when the Lync Conversation Window Extension opens.

