Title: AudioVideoCall - Call Transfer Attended and Unattended.
Description:

The application listens for an incoming Audio Video call, and upon reciept of same, accepts the call, then transfers the inbound call to a  third entity. After the transfer begins, the call is disconnected, regardless of the success/failure of the far leg. The user has theoption (by changing one of the variables declared at the top of the code) whether to opt for attended or unattended transfer (The difference between attended and unattended transfer is that unattended transfers begin the transfer (send the REFER to the far end) and terminate the Call on reciept of the transfer request response (202-Reply to the caller). Attended transfers wait to terminate the call until the subsequent call either succeeds or fails.)
 
The application prints logging to the console, and then quits; shutting the platform down normally.

The application will sit endlessly if run and never called.

Features:

	- Call transfer, and established call activities.
	- Basic Call placement.
	- Basic Audio Video call incoming use.
	- AudioVideoFlow handling and control.

Prerequisites:
	�	Office Communications Server, 2007, R2. (OCS)
	�	Two users capable of sending/receiving Voice calls.
	�	The credentials for those users, and a client capable of logging in to OCS.
	�	A currently logged-in client on Office Communications Server.

Running the sample:
�	Replace the credentials in the variables at the beginning of the code sample with the credentials and server of the users from your OCS topology.
�	Substitute the address of the called user in the code snippet with the address of a valid, currently signed-in user capable of receiving audio calls.
�	Open the project in Visual Studio, and hit F5.
�	Send an voice call to the user who'se credentials the endpoint is using.