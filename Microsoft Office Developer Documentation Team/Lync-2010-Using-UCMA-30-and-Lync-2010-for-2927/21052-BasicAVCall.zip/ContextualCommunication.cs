﻿using System;
using System.Threading;
using System.Text;
using Microsoft.Rtc.Collaboration;
using Microsoft.Rtc.Collaboration.AudioVideo;
using Microsoft.Rtc.Signaling;
using Microsoft.Rtc.Collaboration.Sample.Common;
using System.Net.Mime;
using System.Collections.Generic;


namespace Microsoft.Rtc.Collaboration.Sample.ContextChannelSample
{
  // This application represents a simple outbound InstantMessaging call to a remote user.
  // This application signs in as the specified user, and places an IM call to the targeted user URI.
  // After establishing a conversation with a remote user, the application creates and establishes a 
  // ConversationContextChannel instance. After the context channel is established, the application 
  // receives contextual data from the remote user, and then sends additional contextual data
  // to the remote user.
  // After this application ends the call, it closes the conversation platform, pauses the console to allow logs to be viewed.

  // This application requires the credentials of two Microsoft Lync Server 2010 users.
  // Ensure that the users in question can sign in to Lync Server 2010 with the Lync 2010 credentials provided.
  // Sign in must occur on the computer that runs this code.

  public class UCMABasicIMCall
  {
    // Some necessary instance variables.
    private UCMASampleHelper _helper;
    private InstantMessagingCall _IMCall;
    private InstantMessagingFlow _IMFlow;
    private UserEndpoint _userEndpoint;

    // The information for the conversation and the remote participant.
    // The target of the call in the format sip:user@host (and user should be signed in to the application when the application runs). 
    // Alternative format: tel:+1XXXYYYZZZZ.
    private static String _calledParty;

    // Subject of the conversation that appears in the heading of the conversation window if Lync 2010 is the far-end client.
    private static String _conversationSubject = "Conversation between UCMA and Lync 2010"; 
    private static String _conversationPriority = ConversationPriority.Normal;

    // The conversation.
    private Conversation _conversation;
 
    // The conversation context channel.
    private ConversationContextChannel _channel;
       
  
    // Wait handles are present only to keep things synchronous and easy to read.
    private AutoResetEvent _waitForConversationToTerminate = new AutoResetEvent(false);
    private AutoResetEvent _waitForCallToEstablish = new AutoResetEvent(false);
    private AutoResetEvent _waitForChannelToEstablish = new AutoResetEvent(false);
    private AutoResetEvent _waitForChannelDataToBeSent = new AutoResetEvent(false);
    private AutoResetEvent _waitForCallToTerminate = new AutoResetEvent(false);
    private AutoResetEvent _waitForChannelDataToBeReceived = new AutoResetEvent(false);


    static void Main(string[] args)
    {
      UCMABasicIMCall _basicIMCall= new UCMABasicIMCall();
      _basicIMCall.Run();
    }

    public void Run()
    {
                 
      // Initialize and register the endpoint, using the credentials of the user that the application represents.
      _helper = new UCMASampleHelper();

      _userEndpoint = _helper.CreateEstablishedUserEndpoint("Contextual Communication Sample User" /*endpointFriendlyName*/);
           
      // Set up the conversation.
      ConversationSettings _convSettings = new ConversationSettings();
      _convSettings.Priority = _conversationPriority;
      _convSettings.Subject = _conversationSubject;

      // Conversation represents a collection of modalities in the context of a dialog with one or multiple more call recipients.
      _conversation = new Conversation(_userEndpoint, _convSettings);
            
      _IMCall = new InstantMessagingCall(_conversation);
            
      // Call: StateChanged: Only hooked up for logging.
      _IMCall.StateChanged += new EventHandler<CallStateChangedEventArgs>(IMCall_StateChanged);

      // Subscribe for the flow configuration requested event. The flow is used to send the media.
      // Ultimately, as a part of the callback, the media is sent/received.
      _IMCall.InstantMessagingFlowConfigurationRequested += this.IMCall_FlowConfigurationRequested;

      // Get the URI of the called party.            
      _calledParty = _helper.GetRemoteUserURI();
            
      // Place the call to the remote party.
      _IMCall.BeginEstablish(_calledParty, null, EndCallEstablish, _IMCall);
      Console.WriteLine("\nCalling the remote user...");
      Console.WriteLine("\nConversation ID = {0}", _conversation.Id);


      // Wait for the call to become established.
      _waitForCallToEstablish.WaitOne();

      // Establish the context channel. 
      _channel = new ConversationContextChannel(_conversation, _IMCall.RemoteEndpoint);

      // Register handlers for the DataReceived and StateChanged events on ConversationContextChannel.
      _channel.DataReceived += new EventHandler<ConversationContextChannelDataReceivedEventArgs>(channel_DataReceived);
      _channel.StateChanged += new EventHandler<ConversationContextChannelStateChangedEventArgs>(channel_StateChanged);

      // Configure a set of options for a context channel.
      ConversationContextChannelEstablishOptions channelOptions = new ConversationContextChannelEstablishOptions();
            
      channelOptions.ApplicationName = "Blue Yonder Airlines";
      // Normally used for custom initialization of the remote application.
      channelOptions.ContextualData = "Context channel is open.";  
      // The text that appears in the “toast”.
      channelOptions.Toast = "Get ready for incoming contextual data.";

      // The application ID.
      Guid guid = new Guid("3271E259-E508-4D39-B044-445855591E79");
     
      // Establish a context channel to the remote endpoint.
      _channel.BeginEstablish(guid, channelOptions, BeginEstablishCB, null);
      _waitForChannelDataToBeReceived.WaitOne();

      _channel.BeginTerminate(BeginTerminateCB, null);

      // Terminate the call, and then the conversation.
      _IMCall.BeginTerminate(EndTerminateCall, _IMCall);
      Console.WriteLine("\nWaiting for the call to be terminated...");
      _waitForCallToTerminate.WaitOne();

      _IMCall.Conversation.BeginTerminate(EndTerminateConversation, _IMCall.Conversation);
      Console.WriteLine("\nWaiting for the conversation to be terminated...");
      _waitForConversationToTerminate.WaitOne();

      // CloseShut down the conversation platform.
      Console.WriteLine("\nShutting down the platform...");
      _helper.ShutdownPlatform();

      // Pause the console to allow user to to view logs.
      Console.WriteLine("\nPress any key to end the sample.");
      Console.ReadKey(); 
    }

 
    #region EVENT HANDLERS
  
    // Event handler to record the call state transitions in the console.
    void IMCall_StateChanged(object sender, CallStateChangedEventArgs e)
    {
      Console.WriteLine("\nCall has changed state. The previous call state was: " + e.PreviousState + " and the current state is: " + e.State);
    }

    // Event handler for the StateChanged event on the channel. 
    void channel_StateChanged(object sender, ConversationContextChannelStateChangedEventArgs e)
    {
      Console.WriteLine("\nChannel state change reason is {0}", e.TransitionReason.ToString());
      Console.WriteLine("\nChannel state is {0}", _channel.State.ToString());
    }

    // Flow created indicates that there is a flow present to begin media operations with, and that it is no longer null.
    public void IMCall_FlowConfigurationRequested(object sender, InstantMessagingFlowConfigurationRequestedEventArgs e)
    {
      Console.WriteLine("\nFlow Created.");
      _IMFlow = e.Flow;

      // Now that the flow is non-null, bind the event handler for StateChanged.
      // When the flow goes active, (as indicated by the state changed event) the application can take media-related actions on the flow.
      _IMFlow.StateChanged += new EventHandler<MediaFlowStateChangedEventArgs>(IMFlow_StateChanged);
    }

    private void IMFlow_StateChanged(object sender, MediaFlowStateChangedEventArgs e)
    {
      Console.WriteLine("\nFlow state changed from " + e.PreviousState + " to " + e.State);

      // When flow is active, media operations can begin.
      if (e.State == MediaFlowState.Active)
      {
        // Other samples demonstrate uses for an active flow.
      }
    }

    // Event handler for the DataReceived event on ConversationContextChannel. 
    void channel_DataReceived(object sender, ConversationContextChannelDataReceivedEventArgs e)
    {
      Console.WriteLine("\nRequest data: {0}", e.RequestData.MessageType);
      Console.WriteLine("\nContent type: {0}", e.ContentDescription.ToString());

      // Assume that no more than 100 bytes are sent at a time.
      Byte[] body_byte = new Byte[100];
      body_byte = e.ContentDescription.GetBody();
      SendDataToRemote(body_byte);

      String body_UTF8 = null;
      body_UTF8 = Converter.ConvertByteArrayToString(body_byte, EncodingType.UTF8);

      Console.WriteLine("\nContent body: {0}", body_UTF8);
      _waitForChannelDataToBeReceived.Set();
    }
    #endregion 


    #region HELPER METHODS
    /// <summary>
    /// Parses the input parameter and sends the appropriate data to the remote side of the channel.
    /// </summary>
    /// <param name="data">An array of bytes received from the context channel.</param>
    private void SendDataToRemote(Byte[] data)
    {
      // Each string to be sent consists of three fields, separated by commas or semicolons.
      String strCamera = "SLR X1000,$199.95,In stock";
      String strPhone = "ABC Smartphone,$149.50, In stock";
      String strGPS = "Gourmand XYZ,$210.00, On backorder";
      String strError = "Error,No item chosen,";
      String temp;

      // Convert data to String.
      String tempString = Converter.ConvertByteArrayToString(data, EncodingType.ASCII);

      if (tempString.Equals("Camera")) temp = strCamera;
      else if (tempString.Equals("Smartphone")) temp = strPhone;
      else if (tempString.Equals("GPS")) temp = strGPS;
      else temp = strError;

      // Convert temp to Byte[].
      Byte[] data_bytes = new byte[temp.Length];

      ASCIIEncoding data_ASCII = new ASCIIEncoding();
      data_bytes = data_ASCII.GetBytes(temp);

      ContentType contentType = new ContentType("text/plain; charset=us-ascii");

      _channel.BeginSendData(contentType, data_bytes, BeginSendDataCB, null);
      _waitForChannelDataToBeSent.WaitOne();
    }
    #endregion


    #region CALLBACK METHODS

    private void EndCallEstablish(IAsyncResult ar)
    {
      Call call = ar.AsyncState as Call;
      try
      {
        call.EndEstablish(ar);
        Console.WriteLine("\nThe call with Local Participant: " + 
            call.Conversation.LocalParticipant + 
            " and Remote Participant: " + 
            call.RemoteEndpoint.Participant +
            " is now in the established state.");
        Console.WriteLine("\nConversation ID (in EndCallEstablish) = ", _conversation.Id);
      }
      catch (OperationFailureException opFailEx)
      {
        // OperationFailureException: Indicates failure to connect the call to the remote party.
        // It is left to the application to perform real error-handling here.
        Console.WriteLine(opFailEx.ToString());
      }
      catch (RealTimeException exception)
      {
        // RealTimeException may be thrown on media or link-layer failures.
        // It is left to the application to perform real error-handling here.
        Console.WriteLine(exception.ToString());
      }
      finally
      {
        // Synchronize codethreads.
        _waitForCallToEstablish.Set();
      }
    }

    // Callback for BeginEstablish on ConversationContextChannel.
    private void BeginEstablishCB(IAsyncResult result)
    {
      if (_channel.State == ConversationContextChannelState.Establishing)
      {
        Console.WriteLine("\nChannel is in Establishing state.");
        _channel.EndEstablish(result);
      }
    }

    // Callback for BeginSendData on ConversationContextChannel.
    private void BeginSendDataCB(IAsyncResult ar)
    {
      _channel.EndSendData(ar);
      Console.WriteLine("\nEndSendData() called on channel.");
      _waitForChannelDataToBeSent.Set();
    }

    // Callback for BeginTerminate on ConversationContextChannel.
    private void BeginTerminateCB(IAsyncResult ar)
    {
      _channel.EndTerminate(ar);
    }

    private void EndTerminateCall(IAsyncResult ar)
    {
      InstantMessagingCall IMCall = ar.AsyncState as InstantMessagingCall;

      IMCall.EndTerminate(ar);

      // Synchronize threads.
      _waitForCallToTerminate.Set();
    }

    private void EndTerminateConversation(IAsyncResult ar)
    {
      Conversation conv = ar.AsyncState as Conversation;

      conv.EndTerminate(ar);

      // Synchronize threads.
      _waitForConversationToTerminate.Set();
    }

    #endregion

  }
}
