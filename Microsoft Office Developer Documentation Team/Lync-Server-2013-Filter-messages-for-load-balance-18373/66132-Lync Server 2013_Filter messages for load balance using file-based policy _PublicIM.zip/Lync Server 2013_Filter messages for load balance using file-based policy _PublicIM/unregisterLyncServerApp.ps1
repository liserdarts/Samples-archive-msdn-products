remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/PublicIM"

del 'C:\Program Files\Microsoft Lync server 2013\server\Core\PublicIM.am'
del 'C:\Program Files\Microsoft Lync server 2013\server\Core\Config.txt'

invoke-csManagementStoreReplication

