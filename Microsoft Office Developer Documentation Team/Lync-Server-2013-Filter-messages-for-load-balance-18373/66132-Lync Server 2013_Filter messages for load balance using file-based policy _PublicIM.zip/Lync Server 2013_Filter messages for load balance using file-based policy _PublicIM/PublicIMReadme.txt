
===========================================================================

    Microsoft Lync Server 2013, SDK Samples

    Copyright (c) Microsoft Corporation.  All rights reserved.

===========================================================================

Sample Description
------------------

 PublicIM is an SPL script that demonstrates routing based on hashing
 the user's SIP Uri and looking up the appropriate destination server
 in an external text file.  For each incoming request from an external network,
 this script gets the From: SIP Uri, computes a hash value and indexes
 a text file to get the server address to proxy the request to.  All
 other requests are proxy as is.

 This sample demonstrates:

 - Flat file access.
 - Programmatic next-hop determination
 

Configuration and Setup
-----------------------

 Configure a homeserver with two users. 


Application Installation
------------------------
 To install and run the sample, you will need the following software:
 
 - Windows 2003 Server SP2 and above.
 - Microsoft Lync Server 2013 Home Server
 - Microsoft Lync Server 2013, SDK
 - Two (2) Microsoft Lync 2013 clients.

 - Install the application by running the RegisterLyncServerApp.ps1 from a 
   Lync Server Management Shell console.
 - Uninstall the applicaiton by running the UnregisterLyncServerApp.ps1 from
   a Lync Server Management Shell console.

   Make sure to update the <lync-server-fqdn> placeholder in the PS script 
   to the FQDN of your Lync Server (pool).

 
Running this Sample
-------------------

This sample demonstrates programmatic routing based on user URI.  In
normal topologies, this is not needed, as routing rules suffice for
directing traffic.  However, in some cases it may be useful to add 
additional routing logic, e.g. in a topology where the next-hop servers
(generally proxies) are running custom SIP applications, and users
are 'tied' to specific servers.  The logic in this sample shows how
to do rudimentary load balancing for this kind of topology.

 1. Set up an Access Proxy, as per the Deployment Guide.
 2. Install the PublicIM.am script on the access proxy, as described
    above in Configuration and Setup.
 3. Configure one or more internal servers with Live Communications
    Server, and add the FQDN of each machine to the Config.txt file.
    
Incoming traffic from the outside network will be routed based on the
hash of the From: SIP Uri

File List
---------

 PublicIM.am
 Config.txt
 readme.txt
