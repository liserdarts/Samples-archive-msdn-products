copy PublicIM.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'
copy Config.txt 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.microsoft.com/LC/SDK/Samples/PublicIM" -identity "service:registrar:<lync-sever-fqdn>/PublicIM" -critical $false -priority 5 -scriptname PublicIM.am -enabled $true

invoke-csManagementStoreReplication