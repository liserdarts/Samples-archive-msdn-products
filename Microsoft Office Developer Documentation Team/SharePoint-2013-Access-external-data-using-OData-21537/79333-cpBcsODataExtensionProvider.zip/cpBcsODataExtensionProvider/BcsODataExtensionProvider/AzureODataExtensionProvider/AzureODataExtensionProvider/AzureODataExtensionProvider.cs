﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.BusinessData;
using Microsoft.BusinessData.SystemSpecific;
using Microsoft.BusinessData.SystemSpecific.OData;
using System.Net;
using System.Web;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization.Json;

namespace AzureODataExtensionProvider
{
    public class AzureODataExtensionProvider : ODataExtensionProvider
    {
        public override void AfterReceiveResponse(System.Net.HttpWebResponse response)
        {
            //not implemented
        }

        public override void BeforeSendRequest(System.Net.HttpWebRequest request)
        {
            //Get the access token and append it to the BCS request
            MediaServicesToken mediaServicesToken = GetMediaServicesToken();

            //Modify the request
            request.Accept = "application/json;odata=verbose";
            request.ContentType = "application/json;odata=verbose";
            request.Host = "media.windows.net";
            request.Headers.Add("DataServiceVersion", "3.0");
            request.Headers.Add("MaxDataServiceVersion", "3.0");
            request.Headers.Add("x-ms-version", "1.0");
            request.Headers.Add("Authorization", "Bearer " + mediaServicesToken.access_token);
        }

        private MediaServicesToken GetMediaServicesToken()
        {
            //Parameters for getting the access token
            string url = "https://wamsprodglobal001acs.accesscontrol.windows.net/v2/OAuth2-13";
            string body = "grant_type=client_credentials&client_id={0}&client_secret={1}&scope=urn%3aWindowsAzureMediaServices";
            string accountName = "your_azure_media_services_account";
            string secret = "your_azure_media_services_key";

            //Build request
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            string requestBody = string.Format(CultureInfo.InvariantCulture, body, accountName, HttpUtility.UrlEncode(secret));
            request.ContentLength = Encoding.UTF8.GetByteCount(requestBody);
            request.ContentType = "application/x-www-form-urlencoded";

            using (StreamWriter streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(requestBody);
            }

            //Process response
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(MediaServicesToken));
                MediaServicesToken mediaServicesToken = (MediaServicesToken)serializer.ReadObject(response.GetResponseStream());
                return mediaServicesToken;
            }
        }

    }
}
