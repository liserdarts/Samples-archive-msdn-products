//++
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// Module Name:
//
//  MainPage.xaml.cs
//    
// Abstract:
//
//  The implementation of the main page of the plugin.
//  
//--
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Microsoft.Lync.Model;
using Microsoft.Lync.Model.Conversation;
using VisualStudioContexualPlugin.Resources;

namespace VisualStudioContexualPlugin
{
    public partial class MainPage : UserControl
    {
        //Contextual applications are each identifed by a GUID.
        private const string contextualApplicationGuid = "{d0d57bfe-3cd3-498b-afcf-4bee7dbaabc3}";

        //These constants and a few utility functions are also in the Visual Studio extension. If this wasn't a sample, they would be in a
        //shared utility class.
        private const string ContentType = "text/plain";
        private const string ServerID = "server";
        private const char RecipientSeparator = ';';
        private const string GetTextCommand = "get text";
        private const string TextCommand = "text";
        private const string PutTextCommand = "put text";
        private const string GetEditRightsCommand = "get editing";
        private const string ReleaseEditRightsCommand = "release editing";
        private const string EditRightsCommand = "editing";
        private const string IdentifySelfCommand = "self";

        private string _uri;
        private Conversation _conversation;
        private string _editRightsHolder;
        private bool _changed;

        public MainPage()
        {
            InitializeComponent();
            _editRightsHolder = string.Empty;
            try
            {
                //Gets the conversation whose extensibility pane this plugin is running in.
                _conversation = (Conversation)LyncClient.GetHostingConversation();
                if (_conversation != null)
                {
                    string context = _conversation.GetApplicationData(contextualApplicationGuid);

                    //Extract the data: file name, line number, and content type. The fourth line is a GUID that can be ignored here.
                    //It will look something like:
                    //File.cs
                    //1
                    //CSharp
                    //d0d57bfe-3cd3-498b-afcf-4bee7dbaabc3
                    string[] data = context.Split('\n');
                    FileTextBlock.Text = data[0];
                    LineTextBlock.Text = data[1];
                    TypeTextBlock.Text = data[2];

                    _uri = _conversation.SelfParticipant.Contact.Uri;

                    _conversation.ContextDataSent += HandleContextSentOrReceived;
                    _conversation.ContextDataReceived += HandleContextSentOrReceived;

                    //Send the request for the initial text
                    SendData(ServerID, GetTextCommand, string.Empty);
                }
                else
                {
                    //The alert box that happens by default for errors is hard to read. Show something better here.
                    ShowError(PluginResources.NoConversationErrorMessage);
                }
            }
            catch (Exception e)
            {
                //The alert box that happens by default for errors is hard to read. Show something better here.
                ShowError(e.ToString());
            }
        }

        private void HandleMainRichTextBoxContentChanged(object sender, ContentChangedEventArgs e)
        {
            _changed = true;
        }

        private bool SendData(string recipient, string command, string body)
        {
            try
            {
                _conversation.BeginSendContextData(contextualApplicationGuid, ContentType, string.Format("{0}\n{1}\n{2}\n{3}\n", _uri, recipient, command, body), null, null);
                return true;
            }
            catch (LyncClientException)
            {
                return false;
            }
            catch (SystemException ex)
            {
                if (IsLyncException(ex))
                {
                    return false;
                }
                else
                {
                    // Rethrow the SystemException which did not come from the Lync Model API.
                    throw;
                }
            }
        }

        //Use the header to make sure this context data was intended for this client, then process it.
        private void HandleContextSentOrReceived(object sender, ContextEventArgs e)
        {
            //The first line is the sender, the second is the recipient list, the third is the command, and everything following that is the body
            //Sample:
            //server
            //sip:tester1@example.com;sip:tester2@example.com
            //text
            //[...Formatted text version of document here...]
            string[] lines = e.ContextData.Split('\n');

            //Make sure enough lines are present and that we this was not sent by us.
            if (lines.Length >= 3 && lines[0] != _uri)
            {
                //Multiple recipients are separated by semicolons. Make sure we are one of them.
                string[] dests = lines[1].Split(RecipientSeparator);
                if (dests.Contains(_uri))
                {
                    //The last parameter is everything that follows the third line break.
                    int lineBreaks = lines.Length > 3 ? 3 : 2;
                    ProcessCommand(lines[0], lines[2], e.ContextData.Substring(lines[0].Length + lines[1].Length + lines[2].Length + lineBreaks));
                }
            }
        }

        private void ProcessCommand(string sender, string command, string body)
        {
            //Used to identify that this client is running on the same instance of Communicator as the server. This allows it to save
            //changes in the text back to Visual Studio
            if (command == IdentifySelfCommand)
            {
                SaveButton.Visibility = Visibility.Visible;
            }
            //Text command means display the text contained in the body.
            else if (command == TextCommand)
            {
                ShowFormattedText(body);
            }
            //If the client gets text from another client, it verifies that the sender has the right to edit text.
            else if (command == PutTextCommand && _editRightsHolder == sender)
            {
                ShowPlainText(body);
            }
            else if (command == EditRightsCommand)
            {
                SetEditRightsHolder(body.Trim());
            }
        }

        private void ShowFormattedText(string xaml)
        {
            try
            {
                MainRichTextBox.Xaml = xaml;
            }
            catch (ArgumentException e)
            {
                ShowError(e.ToString());
            }
            //Scroll to top of box.
            TextPointer startPointer = MainRichTextBox.ContentStart;
            MainRichTextBox.Selection.Select(startPointer, startPointer);
        }

        private void ShowPlainText(string text)
        {
            MainRichTextBox.Blocks.Clear();
            MainRichTextBox.Blocks.Add(new Paragraph());
            ((Paragraph)MainRichTextBox.Blocks.First()).Inlines.Add(text);
            //Scroll to top of box.
            TextPointer startPointer = MainRichTextBox.ContentStart;
            MainRichTextBox.Selection.Select(startPointer, startPointer);
        }

        private void SetEditRightsHolder(string rightsHolder)
        {
            //Before doing anything, make sure that the request actually makes a change.
            if (_editRightsHolder != rightsHolder)
            {
                _editRightsHolder = rightsHolder;
                //Turn off the event handler for now, so it doesn't fire now.
                MainRichTextBox.ContentChanged -= HandleMainRichTextBoxContentChanged;
                //This client just got the rights.
                if (_editRightsHolder == _uri)
                {
                    //Get rid of all formatting.
                    foreach (Paragraph p in MainRichTextBox.Blocks)
                    {
                        foreach (Run r in p.Inlines)
                        {
                            r.Foreground = MainRichTextBox.Foreground;
                            r.TextDecorations = null;
                            r.FontStyle = MainRichTextBox.FontStyle;
                            r.FontFamily = MainRichTextBox.FontFamily;
                        }
                    }
                    //Turn event handler back on.
                    MainRichTextBox.ContentChanged += HandleMainRichTextBoxContentChanged;
                    ((TextBlock)EditButton.Content).Text = PluginResources.EditButtonTextEditing;
                    MainRichTextBox.IsReadOnly = false;
                    EditButton.IsEnabled = true;
                    _changed = false;
                }
                //No one has the rights.
                else if (_editRightsHolder == string.Empty)
                {
                    MainRichTextBox.IsReadOnly = true;
                    ((TextBlock)EditButton.Content).Text = PluginResources.EditButtonTextDefault;
                    EditButton.IsEnabled = true;
                    SaveButton.IsEnabled = true;
                }
                //Someone other than this client has the rights.
                else
                {
                    MainRichTextBox.IsReadOnly = true;
//                    ((TextBlock)EditButton.Content).Text = PluginResources.EditButtonTextEditingOtherEditing;
                    EditButton.IsEnabled = false;
                    SaveButton.IsEnabled = false;
                }
            }
        }

        private string OtherParticipants()
        {
            return string.Join(";", from c in _conversation.Participants where c.Contact.Uri != _uri select c.Contact.Uri);
        }

        private void HandleEditButtonClick(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_editRightsHolder == string.Empty)
            {
                SendData(ServerID, GetEditRightsCommand, string.Empty);
            }
            else if (_editRightsHolder == _uri)
            {
                if (_changed)
                {
                    TextPointer start = MainRichTextBox.Selection.Start;
                    TextPointer end = MainRichTextBox.Selection.End;
                    MainRichTextBox.SelectAll();
                    SendData(OtherParticipants(), PutTextCommand, MainRichTextBox.Selection.Text);
                    MainRichTextBox.Selection.Select(start, end);
                    SaveButton.IsEnabled = true;
                }
                SendData(ServerID, ReleaseEditRightsCommand, string.Empty);
            }
            //Button should be disabled in this case, so just ignore.
        }

        private void OnSaveButtonClick(object sender, RoutedEventArgs e)
        {
            TextPointer start = MainRichTextBox.Selection.Start;
            TextPointer end = MainRichTextBox.Selection.End;
            MainRichTextBox.SelectAll();
            SendData(ServerID, PutTextCommand, MainRichTextBox.Selection.Text);
            MainRichTextBox.Selection.Select(start, end);
            SaveButton.IsEnabled = false;
        }

        private void ShowError(string message)
        {
            MainRichTextBox.Blocks.Clear();
            Paragraph paragraph = new Paragraph();
            Run run = new Run();
            run.Foreground = new SolidColorBrush(Colors.Red);
            run.Text = message;
            paragraph.Inlines.Add(run);
            MainRichTextBox.Blocks.Add(paragraph);
        }

        /// <summary>
        /// Identify if a particular SystemException is one of the exceptions which may be thrown
        /// by the Lync Model API.
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        private bool IsLyncException(SystemException ex)
        {
            return
                ex is NotImplementedException ||
                ex is ArgumentException ||
                ex is NullReferenceException ||
                ex is NotSupportedException ||
                ex is ArgumentOutOfRangeException ||
                ex is IndexOutOfRangeException ||
                ex is InvalidOperationException ||
                ex is TypeLoadException ||
                ex is TypeInitializationException ||
                ex is InvalidCastException;
        }

    }
}
