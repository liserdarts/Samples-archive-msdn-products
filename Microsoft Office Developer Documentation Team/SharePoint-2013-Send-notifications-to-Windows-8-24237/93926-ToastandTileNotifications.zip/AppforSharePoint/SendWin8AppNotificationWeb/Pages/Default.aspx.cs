﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SendWin8AppNotificationWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.Page.Request.QueryString["ChannelUrl"]))
            {
                Application["ChannelUrl"] = this.Page.Request.QueryString["ChannelUrl"];
                return;
            }

            if (Application["ChannelUrl"] != null)
            {
                Label1.Text = string.Format("ChannelUrl: {0}", Application["ChannelUrl"]);
            }
            else
            {
                Label1.Text = "The ChannelUrl was not set by the Windows 8 App yet. Please open the Windows 8 App to set the ChannelUrl, and then refresh the page again.";
                Panel1.Visible = false;
            }
        }

        protected void btnSemdTileNotification_Click(object sender, EventArgs e)
        {
            WNSUtil.SendTileNotification(txt_tileNotificationTemplate.Text, Application["ChannelUrl"].ToString());
        }

        protected void btnSemdToastNotification_Click(object sender, EventArgs e)
        {
            WNSUtil.SendToastNotification(txt_toastNotificationTemplate.Text, Application["ChannelUrl"].ToString());
        }
    }
}