$DuetMuiProductCodeStr = "{90140000-00BF-0XXX-1000-0000000FF1CE}";
$lcids = @();

$registryKey = "SOFTWARE\Microsoft\Duet Enterprise\1.0\InstalledLang";
[Microsoft.Win32.RegistryKey]$duetRegistryKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($registryKey);

if ($duetRegistryKey -ne $null)
{
    $lcids += $duetRegistryKey.GetValueNames();
}

$cultures = @($lcids | Where-Object { $_ -ne "1033"});

"Installed Cultures: $cultures";

foreach($culture in $cultures)
{
	$cultureCode = "{0:x}" -f [int]$culture;
	$DuetMuiProductCode = $DuetMuiProductCodeStr.Replace("XXX",  $cultureCode);
	
	$msiArgs = "/X$DuetMuiProductCode /quiet RUNNINGFROMSETUP=TRUE";
	
	"Uninstalling culture: $culture";
	$exitCode = (Start-Process -FilePath "msiexec.exe" -ArgumentList $msiArgs -Wait -Passthru).ExitCode;
	if($exitCode -ne 0)
	{
		"Error in uninstalling. Error Code: $exitCode";
	}
	else
	{
		"Successfully uninstalled culture: $culture";
	}
}

iisreset
