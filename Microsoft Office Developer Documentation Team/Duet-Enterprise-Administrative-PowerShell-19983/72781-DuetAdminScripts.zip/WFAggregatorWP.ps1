Param( 
	[Parameter(Mandatory = $true)] 
        [String] 
        $url
)

$wfrootWeb = Get-SPWeb $url

if($wfrootWeb.Webs.Count -ne 0)
{

foreach($web in $wfrootWeb.Webs)
{

$webUrl = $web.Url;

"Processing web: $webUrl";

[Microsoft.SharePoint.SPFile]$file = $web.GetFile("default.aspx");

[Microsoft.SharePoint.WebPartPages.SPLimitedWebPartManager]$limitedWebPartManager = $file.GetLimitedWebPartManager([System.Web.UI.WebControls.WebParts.PersonalizationScope]::Shared);

[Microsoft.SharePoint.WebPartPages.SPLimitedWebPartCollection]$webPartCollection = $limitedWebPartManager.WebParts;

foreach($webPart in $webPartCollection)
{
	if($webPart.ErrorMessage -ne $null)
	{
		
	if($webPart.ErrorMessage.Contains("SAP.Office.DuetEnterprise.Workflow.TasksAggregationWP"))
	{
	"Found webpart on : $webUrl";
		[System.Web.UI.WebControls.Unit]$height = $webPart.Height;
        [System.Web.UI.WebControls.Unit]$width = $webPart.Width;
        $title = $webPart.DisplayTitle;
        [System.Web.UI.WebControls.WebParts.PartChromeType]$chromeType = $webPart.ChromeType;
        $zoneID = $webPart.ZoneID;
        [int]$zoneIndex = $webPart.ZoneIndex;
		
		$limitedWebPartManager.DeleteWebPart($webPart);
		
		
		[Microsoft.SharePoint.SPList]$webPartGallery = $web.Site.RootWeb.GetCatalog([Microsoft.SharePoint.SPListTemplateType]::WebPartCatalog);
		[Microsoft.SharePoint.SPQuery]$query = New-Object -TypeName "Microsoft.SharePoint.SPQuery";
		$query.Query = "<Where><Eq><FieldRef Name='FileLeafRef'/><Value Type='File'>TasksAggregationWP.webpart</Value></Eq></Where>";
		[Microsoft.SharePoint.SPListItemCollection]$items = $webPartGallery.GetItems($query);
		
		[System.IO.Stream]$xmlStream = $items[0].File.OpenBinaryStream();
        [System.IO.StreamReader]$sReader = New-Object -TypeName "System.IO.StreamReader" -ArgumentList $xmlStream;
        [System.IO.StringReader]$strReader = New-Object -TypeName "System.IO.StringReader" -ArgumentList $sReader.ReadToEnd();
        [System.Xml.XmlReader]$xmlReader = [System.Xml.XmlReader]::Create($strReader);
		
		$errorMsg = "";
		[System.Web.UI.WebControls.WebParts.WebPart]$newWebPart = $limitedWebPartManager.ImportWebPart($xmlReader, [ref]$errorMsg);
		
		$newWebPart.ChromeType = $chromeType;
		$limitedWebPartManager.AddWebPart($newWebPart, $zoneID, $zoneIndex);
		"Done";
	break;
	}
	}
}

}

}
