"Copying stsadm.exe file ..."
$Drive=$env:PROGRAMFILES
$SourceFile=$Drive +"\Common Files\Microsoft Shared\Web Server Extensions\15\BIN\stsadm.exe"
$DestinationPath=$Drive + "\Common Files\Microsoft Shared\Web Server Extensions\14\BIN"
New-Item $DestinationPath -type directory -Force

copy-Item $SourceFile $DestinationPath
"Copied Stsadm.exe successfully."
