$scriptblock = {
"Current thread culture " + [System.Threading.Thread]::CurrentThread.CurrentCulture.LCID;
[System.Reflection.Assembly]$assembly = [System.Reflection.Assembly]::LoadWithPartialName("OBA.Server.Common, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
[Microsoft.SharePoint.Administration.Health.SPHealthAnalyzer]::UnregisterRules($assembly);
"Successfully unregistered health rules";
}

$OldCulture = [System.Threading.Thread]::CurrentThread.CurrentCulture

$SPLcid = [Microsoft.SharePoint.SPRegionalSettings]::GlobalServerLanguage.LCID
$SharePointCulture = New-Object -TypeName "System.Globalization.CultureInfo" -ArgumentList $SPLcid

$invarLcid = [System.Globalization.CultureInfo]::InvariantCulture.LCID
$invariantCulture = New-Object -TypeName "System.Globalization.CultureInfo" -ArgumentList $invarLcid
    trap 
    {
        [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
    }

    [System.Threading.Thread]::CurrentThread.CurrentCulture = $SharePointCulture 
    Invoke-Command $scriptblock
    
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $invariantCulture 
    Invoke-Command $scriptblock
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
