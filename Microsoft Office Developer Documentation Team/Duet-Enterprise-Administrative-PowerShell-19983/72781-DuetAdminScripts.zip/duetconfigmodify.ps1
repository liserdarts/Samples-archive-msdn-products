$Drive=$env:PROGRAMFILES
$SourceFile=$Drive +"\Duet Enterprise\1.0\DuetConfig.exe.config"
$DestinationPath=$Drive + "\Duet Enterprise\1.0\DuetConfig.exe.config.bak"
copy-Item $SourceFile $DestinationPath

$old = "^</configuration>"
$new = "<startup><supportedRuntime version=`"v4.0`"/></startup></configuration>"
$newContent = Get-Content $DestinationPath | ForEach-Object {$_ -replace $old, $new }
Set-Content $SourceFile $newContent
