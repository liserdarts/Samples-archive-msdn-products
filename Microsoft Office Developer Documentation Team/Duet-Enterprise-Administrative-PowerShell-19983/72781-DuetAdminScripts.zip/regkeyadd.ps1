$Drive=$env:PROGRAMFILES
$RegValue= $env:PROGRAMFILES + "\Microsoft Office Servers\14.0\"
$RegKey='HKLM:\SOFTWARE\Microsoft\Office Server\14.0'

if (Test-Path $RegKey) {  
    "Registry key "+$RegKey +" already exists."  
} else {  
    md $RegKey
    New-ItemProperty  $RegKey -Name "InstallPath" -Value $RegValue -PropertyType "String"
    "Registry key created Successfully."
}


#OR Use following one line choose Yes for
#reg add "HKLM\SOFTWARE\Microsoft\Office Server\14.0" /v "InstallPath" /t REG_EXPAND_SZ /d "%PROGRAMFILES%\Microsoft Office Servers\14.0\"
#Yes
