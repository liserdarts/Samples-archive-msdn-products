copy ClientFilter.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'
copy FullMatch_Config.txt 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'
copy PartialMatch_Config.txt 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "www.microsoft.com/LC/SDK/Samples/ClientFilter" -identity "service:registrar:<lync-sever-fqdn>/ClientFilter" -critical $false -priority 5 -scriptname ClientFilter.am -enabled $true

invoke-csManagementStoreReplication