remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/ClientFilter"

del 'C:\Program Files\Microsoft Lync server 2013\server\Core\ClientFilter.am'
del 'C:\Program Files\Microsoft Lync server 2013\server\Core\FullMatch_Config.txt'
del 'C:\Program Files\Microsoft Lync server 2013\server\Core\PartialMatch_Config.txt'

invoke-csManagementStoreReplication

