﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;

namespace AutohostedAppWithDBWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {
        string AppUserName = "default";
        SharePointContextToken contextToken;
        string accessToken;
        Uri sharepointUrl;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            // The following code gets the client context and Title property by using TokenHelper.
            // To access other properties, you may need to request permissions on the host web.
            
            //var contextTokenString = TokenHelper.GetContextTokenFromRequest(Page.Request);
            //var hostWeb = Page.Request["SPHostUrl"];

            //using (var clientContext = TokenHelper.GetClientContextWithContextToken(hostWeb, contextTokenString, Request.Url.Authority))
            //{
            //    clientContext.Load(clientContext.Web, web => web.Title);
            //    clientContext.ExecuteQuery();
            //    Response.Write(clientContext.Web.Title);
            //    clientContext.ToString();
            //}

            // Display the current connection string (don't do this in production). 
            Response.Write("<h2>Database Server</h2>");
            Response.Write("<p>" + GetDBServer() + "</p>");

            // Display the query results. 
            Response.Write("<h2>SQL Data</h2>");

            //using (SqlConnection conn = GetActiveSqlConnection())
            //{
            //    using (SqlCommand cmd = conn.CreateCommand())
            //    {
            //        conn.Open();

            //     //   cmd.CommandText = "select * from UserFavorites where User='Bob'";
            //      //  cmd.CommandText = "SELECT * FROM UserFavorites WHERE Favorite1='www.bing.com'"; //cmd.CommandText = "SELECT * FROM UserFavorites WHERE Favorite1='www.bing.com'";
            //      //  cmd.CommandText = "SELECT * FROM UserFavorites WHERE User='www.bing.com'";
            //        cmd.CommandText = String.Format("SELECT * FROM UserFavorites WHERE AppUser='{0}'", "Mary");
            //        Response.Write("<p>" + cmd.CommandText + "</p>");

            //        using (SqlDataReader reader = cmd.ExecuteReader())
            //        {
                        
            //            Response.Write("<p>" + reader.HasRows.ToString() + "</p>");
            //            while (reader.Read())
            //            {
            //                Response.Write("<p>" + reader["AppUser"].ToString() + "</p>");
            //                Response.Write("<p>" + reader["Favorite1"].ToString() + "</p>");
            //                Response.Write("<p>" + reader["Favorite2"].ToString() + "</p>");
            //                Response.Write("<p>" + reader["Favorite3"].ToString() + "</p>");
            //                Response.Write("<p>" + reader["AppUser1"].ToString() + "</p>");
            //            }
            //        }
            //    }
            //} 

        }

        protected string GetDBServer()
        {
            string conn = GetCurrentConnectionString();
            string[] parts = conn.Split(new char[] {';'});
            string[] dataSource = parts[0].Split(new char[] { '=' });
            return dataSource[1];
        }

        protected SqlConnection GetActiveSqlConnection()
        {
            return new SqlConnection(GetCurrentConnectionString());
        }

        protected string GetCurrentConnectionString()
        {
            return WebConfigurationManager.AppSettings["SqlAzureConnectionString"];
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
           
            AppUserName = txtBoxAppUserName.Text;
            Response.Write("<p>" + AppUserName + "</p>");

            using (SqlConnection conn = GetActiveSqlConnection())
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();

                    //   cmd.CommandText = "select * from UserFavorites where User='Bob'";
                    //  cmd.CommandText = "SELECT * FROM UserFavorites WHERE Favorite1='www.bing.com'"; //cmd.CommandText = "SELECT * FROM UserFavorites WHERE Favorite1='www.bing.com'";
                    //  cmd.CommandText = "SELECT * FROM UserFavorites WHERE User='www.bing.com'";
                    cmd.CommandText = String.Format("SELECT * FROM UserFavorites WHERE AppUser='{0}'", AppUserName);
                    Response.Write("<p>" + cmd.CommandText + "</p>");

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {

                        Response.Write("<p>" + reader.HasRows.ToString() + "</p>");
                        while (reader.Read())
                        {
                            Response.Write("<p>" + reader["AppUser"].ToString() + "</p>");
                            Response.Write("<p>" + reader["Favorite1"].ToString() + "</p>");
                            Response.Write("<p>" + reader["Favorite2"].ToString() + "</p>");
                            Response.Write("<p>" + reader["Favorite3"].ToString() + "</p>");
                            Response.Write("<p>" + reader["AppUser1"].ToString() + "</p>");
                        }
                    }
                }
            } 
        }


    }
}