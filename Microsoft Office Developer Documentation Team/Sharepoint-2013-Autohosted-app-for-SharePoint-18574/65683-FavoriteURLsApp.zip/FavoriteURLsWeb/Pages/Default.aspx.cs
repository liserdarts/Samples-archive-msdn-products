﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;
using System.Text;

namespace FavoriteURLsWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {        
        // The following two methods encapsulate the retrieval of a connection to the 
        // SQL Azure database. We recommend doing this because the technique by which 
        // the connection is obtained may change between the preview version of 
        // SharePoint autohosted apps and the final release version. The encapsulation
        // will minmize the changes you will have to make to your autohosted apps
        // following final release.
        protected SqlConnection GetActiveSqlConnection()
        {
            return new SqlConnection(GetCurrentConnectionString());
        }

        protected string GetCurrentConnectionString()
        {
            return WebConfigurationManager.AppSettings["SqlAzureConnectionString"];
        }

        // Test for a value user name, open connection to the database, and send the 
        // name.
        protected void btnShowFavorites_Click(object sender, EventArgs e)
        {
            // Handle case where user press the button without first entering a name.
            if (String.IsNullOrEmpty(txtBoxAppUserName.Text))
            {
                lblShowFavoritesPrompt.Text = "Please enter your user name and press Login.";
                lblShowFavoritesPrompt.ForeColor = System.Drawing.Color.Red;
                return;
            }
            
            using (SqlConnection conn = GetActiveSqlConnection())
            using (SqlCommand cmd = conn.CreateCommand())
            {
                conn.Open();
                DisplayFavorites(cmd, txtBoxAppUserName.Text);

            }//dispose conn and cmd
        }

        // Define and execute the SQL command.
        private void DisplayFavorites(SqlCommand cmd, String appUserName)
        {
            cmd.CommandText = String.Format("SELECT * FROM UserFavorites WHERE AppUser='{0}'", appUserName);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        RenderDataAsHtmlList(reader);
                    }

                    // Show the user favorites retrieved from the database.
                    SwitchToForm("frmFavorites");
                }
                else // The user is unknown, so show the registration form.
                {
                    SwitchToForm("frmRegister");
                }
            }
        }

        // Fill the favorites list with data and make it visible.
        private void RenderDataAsHtmlList(SqlDataReader reader)
        {
            lblUser.Text = reader["AppUser"].ToString() + "'s Favorite URLs:";

            url1.HRef = "http://" + reader["Favorite1"].ToString();
            url1.InnerText = reader["Favorite1"].ToString();
            url2.HRef = "http://" + reader["Favorite2"].ToString();
            url2.InnerText = reader["Favorite2"].ToString();
            url3.HRef = "http://" + reader["Favorite3"].ToString();
            url3.InnerText = reader["Favorite3"].ToString();
            url4.HRef = "http://" + reader["Favorite4"].ToString();
            url4.InnerText = reader["Favorite4"].ToString();

            favoritesList.Visible = true;
        }

		// Switch between the Show Favorites and the Register forms.
        // Always blank out data that may be present from the last time the form
        // was visible.
        private void SwitchToForm(String formName)
		{
		    if (formName == "frmFavorites")
	        {
		        frmRegister.Visible = false;  

				txtBoxAppUserName.Text = "";                  
				lblShowFavoritesPrompt.Text = "Enter another user name to see his or her favorites:";

				frmFavorites.Visible = true; 
	        }
		    else
	        {
			    frmFavorites.Visible = false;
                favoritesList.Visible = false;

			    txtBoxNewUserName.Text = "";
			    txtBoxFavorite1.Text = "";
			    txtBoxFavorite2.Text = "";
			    txtBoxFavorite3.Text = "";
			    txtBoxFavorite4.Text = "";

			    frmRegister.Visible = true; 
	        }
		}

        // Add the new user's name and favorites to the database.
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Handle case where the user presses the Register button when the 
            // name textbox is empty.
            if (String.IsNullOrEmpty(txtBoxNewUserName.Text))
            {
                lblForgotNamePrompt.Visible = true;
                return;
            }

            lblForgotNamePrompt.Visible = false;

            // Create a connection to the database, and then create and execute
            // the SQL command.
            using (SqlConnection conn = GetActiveSqlConnection())
            using (SqlCommand cmd = conn.CreateCommand())
            {
                conn.Open();

                cmd.CommandText = String.Format("INSERT INTO UserFavorites VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')", 
                                                 txtBoxNewUserName.Text, 
                                                 txtBoxFavorite1.Text, 
                                                 txtBoxFavorite2.Text, 
                                                 txtBoxFavorite3.Text, 
                                                 txtBoxFavorite4.Text);

                cmd.ExecuteNonQuery();

                DisplayFavorites(cmd, txtBoxNewUserName.Text);

            }//dispose conn and cmd
        }        
    }
}