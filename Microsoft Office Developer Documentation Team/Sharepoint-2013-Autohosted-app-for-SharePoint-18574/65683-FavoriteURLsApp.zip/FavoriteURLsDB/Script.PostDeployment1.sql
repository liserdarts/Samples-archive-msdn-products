﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
delete from UserFavorites
insert into UserFavorites values ('Bob', 'www.microsoft.com', 'msdn.microsoft.com', 'www.msn.com', 'www.bing.com')
insert into UserFavorites values ('Mary', 'www.bing.com', 'www.microsoft.com/en-us/download', 'msdn.microsoft.com', 'www.msn.com')