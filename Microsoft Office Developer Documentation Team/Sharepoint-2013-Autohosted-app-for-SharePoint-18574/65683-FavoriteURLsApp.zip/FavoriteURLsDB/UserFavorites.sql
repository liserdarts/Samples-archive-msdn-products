﻿CREATE TABLE [dbo].[UserFavorites]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
	[AppUser] NVARCHAR(50) NULL,
    [Favorite1] NVARCHAR(50) NULL, 
    [Favorite2] NVARCHAR(50) NULL, 
    [Favorite3] NVARCHAR(50) NULL, 
    [Favorite4] NVARCHAR(50) NULL 
)

