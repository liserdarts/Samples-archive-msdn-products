copy ContentModification.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.microsoft.com/LC/SDK/Samples/ContentModification" -identity "service:registrar:<lync-sever-fqdn>/ContentModification" -critical $false -priority 5 -scriptname ContentModification.am -enabled $true

invoke-csManagementStoreReplication