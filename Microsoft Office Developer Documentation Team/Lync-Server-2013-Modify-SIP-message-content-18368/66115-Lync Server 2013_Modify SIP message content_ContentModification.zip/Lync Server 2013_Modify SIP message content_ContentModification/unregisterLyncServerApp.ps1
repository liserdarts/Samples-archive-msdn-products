remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/ContentModification"

del 'C:\Program Files\Microsoft Lync server 2013\server\Core\ContentModification.am'

invoke-csManagementStoreReplication

