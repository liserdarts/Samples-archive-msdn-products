
===========================================================================

    Microsoft Lync Server 2013, SDK Samples

    Copyright (c) Microsoft Corporation.  All rights reserved.

===========================================================================


Sample Description
------------------

 ContentModification is a sample that demonstrates content body modification
 from SPL.  Incoming INVITEs and MESSAGEs are scanned for a substring ("echo");
 if found, the content body is modified.
 
 Features demonstrated:
 
 - Message content inspection
 - Content body modification

 
Application Installation
------------------------
 To install and run the sample, you will need the following software:
 
 - Windows 2003 Server SP2 and above.
 - Microsoft Lync Server 2013 Home Server
 - Microsoft Lync Server 2013, SDK
 - Two (2) Microsoft Lync 2013 clients.

 - Install the application by running the RegisterLyncServerApp.ps1 from a 
   Lync Server Management Shell console.
 - Uninstall the applicaiton by running the UnregisterLyncServerApp.ps1 from
   a Lync Server Management Shell console.

   Make sure to update the <lync-server-fqdn> placeholder in the PS script 
   to the FQDN of your Lync Server (pool).

 
Running this Sample
-------------------

 Login both users, and add each user to the other's contact list, if not
 already added.  Verify that each client's instant messages arrive unmodified, 
 except when the word "echo" appears in the message.


File List
---------

 ContentModification.am

