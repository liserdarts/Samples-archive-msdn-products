﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.SharePoint.Client;
using Microsoft.BusinessData;
using Microsoft.BusinessData.Infrastructure;
using Microsoft.BusinessData.Runtime;
using Microsoft.BusinessData.MetadataModel;
using Microsoft.BusinessData.MetadataModel.Collections;

namespace BCSDashboardCSOMWeb
{
    public class Query
    {
        ClientContext ctx;
        private Entity ect;
        private LobSystem lob;
        private LobSystemInstanceCollection lobis;
        private LobSystemInstance lobi;
        private FilterCollection filters;
        private string entityNamespace { get; set; }
        private string entityName { get; set; }
        private string lobSystemInstanceName { get; set; }
        private string methodInstanceName { get; set; }
        private string appWebUrl { get; set; }

        public Query() { }
        public Query(string EntityNamespace, string EntityName, string LobSystemInstanceName, string MethodInstanceName, string AppWebUrl)
        {
            ctx = new ClientContext(AppWebUrl);
            
            //Save basic ECT parameters
            entityNamespace = EntityNamespace;
            entityName = EntityName;
            lobSystemInstanceName = LobSystemInstanceName;
            methodInstanceName = MethodInstanceName;
            appWebUrl = AppWebUrl;

            //Get entity
            ect = ctx.Web.GetAppBdcCatalog().GetEntity(EntityNamespace, EntityName);
            ctx.Load(ect);

            //Get LobSystem 
            lob = ect.GetLobSystem();
            ctx.Load(lob);

            //Get LobSystemInstances
            lobis = lob.GetLobSystemInstances();
            ctx.Load(lobis);
            ctx.ExecuteQuery();

            //Get LobSystemInstance
            lobi = lobis.Where(l => l.Name == LobSystemInstanceName).First();
            ctx.Load(lobi);

            //Get Filters
            filters = ect.GetFilters(MethodInstanceName);
            ctx.Load(filters);
            ctx.ExecuteQuery();
        }

        public List<Category> GetAllCategories()
        {

            Microsoft.BusinessData.MetadataModel.Collections.EntityInstanceCollection results = ect.FindFiltered(filters, methodInstanceName, lobi);
            ctx.Load(results);
            ctx.ExecuteQuery();

            List<Category> categories = new List<Category>();

            foreach (var result in results)
            {
                object categoryId = null;
                result.FieldValues.TryGetValue("CategoryID", out categoryId);
                object categoryName = null;
                result.FieldValues.TryGetValue("CategoryName", out categoryName);

                Category category = new Category();
                category.CategoryID = int.Parse(categoryId.ToString());
                category.CategoryName = categoryName.ToString();

                categories.Add(category);
            }

            return categories;
        }

        public List<CategorySale> GetCategorySales(string CategoryName)
        {

            filters.SetFilterValue("CategoryNameFilter", 0, CategoryName);
            
            Microsoft.BusinessData.MetadataModel.Collections.EntityInstanceCollection results = ect.FindFiltered(filters, methodInstanceName, lobi);
            ctx.Load(results);
            ctx.ExecuteQuery();

            List<CategorySale> categorySales = new List<CategorySale>();

            foreach (var result in results)
            {
                object categoryName = null;
                result.FieldValues.TryGetValue("CategoryName", out categoryName);
                object categoryAmount = null;
                result.FieldValues.TryGetValue("CategorySales", out categoryAmount);

                CategorySale categorySale = new CategorySale();
                categorySale.CategoryAmount = String.Format("{0:C}", decimal.Parse(categoryAmount.ToString()));
                categorySale.CategoryName = categoryName.ToString();

                categorySales.Add(categorySale);
            }

            return categorySales;
        }
    }
}