﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Client;

namespace BCSDashboardCSOMWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {
        Uri appWeb;

        protected void Page_Load(object sender, EventArgs e)
        {
            appWeb = new Uri(Request.QueryString["SPAppWebUrl"]);

            if (!Page.IsPostBack)
            {
                Query categoryQuery = new Query(
                         "NorthwindModel",
                         "Categories",
                         "NorthwindTraders",
                         "ReadAllCategory",
                         appWeb.AbsoluteUri);

                List<Category> categories = categoryQuery.GetAllCategories();
                categorySelector.DataSource = categories;
                categorySelector.DataValueField = "CategoryName";
                categorySelector.DataBind();
            }
        }

        protected void categorySelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            Query categorySaleQuery = new Query(
                     "NorthwindModel",
                     "Category_Sales_for_1997",
                     "NorthwindTraders",
                     "ReadAllCategory_Sales_for_1997",
                     appWeb.AbsoluteUri);

            List<CategorySale> salesFigures = new List<CategorySale>();

            foreach (System.Web.UI.WebControls.ListItem item in categorySelector.Items)
            {
                if (item.Selected == true)
                {
                    List<CategorySale> categorySales = categorySaleQuery.GetCategorySales(item.Value);
                    salesFigures.AddRange(categorySales);
                }
            }

            salesResults.DataSource = salesFigures;
            salesResults.DataBind();
        }
    }
}