﻿"use strict";

var Northwind = window.Northwind || {};

//object for holding a category instance
Northwind.Category = function (id, name) {

    var categoryId = id,
        get_categoryId = function () { return categoryId; },
        set_categoryId = function (v) { categoryId = v; },
        categoryName = name,
        get_categoryName = function () { return categoryName; },
        set_categoryName = function (v) { categoryName = v; };

    return {
        get_categoryName: get_categoryName,
        set_categoryName: set_categoryName,
        get_categoryId: get_categoryId,
        set_categoryId: set_categoryId
    }

}

//object for holding a category sales figure instance
Northwind.CategorySale = function (name, value) {

    var saleValue = value,
        get_saleValue = function () { return saleValue; },
        set_saleValue = function (v) { saleValue = v; },
        categoryName = name,
        get_categoryName = function () { return categoryName; },
        set_categoryName = function (v) { categoryName = v; };

    return {
        get_categoryName: get_categoryName,
        set_categoryName: set_categoryName,
        get_saleValue: get_saleValue,
        set_saleValue: set_saleValue
    }

}

//the view model for the list of available categories
Northwind.CategoryViewModel = function () {

    var categories = ko.observableArray(),

        //categories is an observable array
        get_categories = function () { return categories; },

        //loads the observable array from the external list
        load = function () {

            Northwind.CategoryQuery.execute().promise().then(
                //success
                function (data) {
                    $.each(data.d.results, function (key, val) {
                        categories.push(new Northwind.Category(val.CategoryID, val.CategoryName));
                    });
                },
                //failure
                function (err) {
                    alert(JSON.stringify(err));
                }
            );
        };

    return {
        load: load,
        get_categories: get_categories
    }

}();

//the view model for category sales figures
Northwind.CategorySalesViewModel = function () {

    var categorySales = ko.observableArray(),

        //the sales figures are in an observable array so the
        //display will change whenver the array is updated
        get_categorySales = function () { return categorySales; },

        //allows for removing a category when it is unchecked
        remove_categorySale = function (categoryName) {
            var categorySale = ko.utils.arrayFirst(categorySales(), function (currentCategorySale) {
                return currentCategorySale.get_categoryName() === categoryName;
            });
            if (categorySale) {
                categorySales.remove(categorySale);
            }
        },

        //hold any previous queries so they do not have to be run again
        deferreds = [],

        //loads the sales figures for a given category
        load = function (categoryName) {

            //look to see if this query has been run already
            var activeDeferred;
            for (var i = 0; i < deferreds.length; i++) {
                if (deferreds[i].categoryName === categoryName) {
                    activeDeferred = deferreds[i];
                    break;
                }
            }

            //if not run already, then make a new instance for this category
            if (!activeDeferred) {
                activeDeferred = new Northwind.CategorySalesQuery().execute(categoryName);
                deferreds[deferreds.length] = activeDeferred;
            }

            //Execute the query
            activeDeferred.promise().then(
                //success
                function (data) {
                    $.each(data.d.results, function (key, val) {
                        categorySales.push(new Northwind.CategorySale(
                                           val.CategoryName,
                                           Northwind.Utilities.formatCurrency(val.CategorySales)));
                    });
                },
                //failure
                function (err) {
                    alert(JSON.stringify(err));
                }
            );
        };

    return {
        load: load,
        get_categorySales: get_categorySales,
        remove_categorySale: remove_categorySale
    }

}();

//Just a utility for formatting the sales figures
Northwind.Utilities = function () {

    var formatCurrency = function (amount) {
        var i = parseFloat(amount);
        if (isNaN(i)) { i = 0.00; }
        var minus = '';
        if (i < 0) { minus = '-'; }
        i = Math.abs(i);
        i = parseInt((i + .005) * 100);
        i = i / 100;
        var s = new String(i);
        if (s.indexOf('.') < 0) { s += '.00'; }
        if (s.indexOf('.') == (s.length - 2)) { s += '0'; }
        s = minus + s;
        s = "$" + formatCommas(s);
        return s;
    },

    formatCommas = function (amount) {
        var delimiter = ",";
        amount = new String(amount);
        var a = amount.split('.', 2)
        var d = a[1];
        var i = parseInt(a[0]);
        if (isNaN(i)) { return ''; }
        var minus = '';
        if (i < 0) { minus = '-'; }
        i = Math.abs(i);
        var n = new String(i);
        var a = [];
        while (n.length > 3) {
            var nn = n.substr(n.length - 3);
            a.unshift(nn);
            n = n.substr(0, n.length - 3);
        }
        if (n.length > 0) { a.unshift(n); }
        n = a.join(delimiter);
        if (d.length < 1) { amount = n; }
        else { amount = n + '.' + d; }
        amount = minus + amount;
        return amount;
    };

    return {
        formatCurrency: formatCurrency
    }

}();