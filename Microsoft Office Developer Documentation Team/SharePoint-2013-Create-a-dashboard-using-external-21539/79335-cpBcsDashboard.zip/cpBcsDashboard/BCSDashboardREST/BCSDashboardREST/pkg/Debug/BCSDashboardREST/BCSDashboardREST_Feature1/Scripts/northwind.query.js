﻿"use strict";

var Northwind = window.Northwind || {};

//the module for executing a query against the list of categories
Northwind.CategoryQuery = function () {

    var deferred = $.Deferred(),

        execute = function () {

            $.ajax({
                url: _spPageContextInfo.webServerRelativeUrl +
                    "/_api/lists/getByTitle('Categories')/items?$select=CategoryID,CategoryName",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                },
                success: onSuccess,
                error: onError
            });

            return deferred;

        },

        onSuccess = function (data) {
            deferred.resolve(data);
        },

        onError = function (err) {
            deferred.reject(err);
        };

    return {
        execute: execute
    }
}();

//the module for executing a query against the list of sales figures
Northwind.CategorySalesQuery = function () {

    var deferred = $.Deferred(),

        execute = function (categoryName) {

            $.ajax({
                url: _spPageContextInfo.webServerRelativeUrl +
                    "/_api/lists/getByTitle('Category_Sales_for_1997')/items?$select=CategoryName,CategorySales&$filter=CategoryName eq '" +
                    categoryName + "'",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                },
                success: onSuccess,
                error: onError
            });

            deferred.categoryName = categoryName;
            return deferred;

        },

        onSuccess = function (data) {
            deferred.resolve(data);
        },

        onError = function (err) {
            deferred.reject(err);
        };

    return {
        execute: execute
    }
};