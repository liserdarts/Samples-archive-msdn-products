﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;

namespace JSONPWebsite
{
    public partial class proxy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var feedurl = Request["feedUrl"];
            var callBack = Request["callback"];

            string jsonText = "{\"error\": \"invalid feed url\"}";

            Response.Clear();

            Response.ContentType = "application/json";

            if (!string.IsNullOrEmpty(feedurl) && !string.IsNullOrEmpty(callBack))
            {
                try
                {
                    XmlDocument document = new XmlDocument();

                    document.Load(feedurl);

                    jsonText = string.Format("{0}([{1}])", callBack, JsonConvert.SerializeXmlNode(document.SelectSingleNode("rss")));
                }
                catch
                {

                }
            }

            Response.Write(jsonText);

            Response.End();

        }
    }
}