﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Web;

namespace SalesTaxCalcService
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession, MaxItemsInObjectGraph = 65536000)]
    [ServiceContract]
    public class SalesTaxCalculator
    {
        List<string> TaxFreeCities = new List<string>() 
        {
            "Oregon",
            "Portland",
            "Eugene",
            "Salem",
            "Gresham",
            "Bend",
            "Alaska",
            "Delaware",
            "Montana"
        };

        [OperationContract]
        [WebGet(UriTemplate = "/{cityname}", ResponseFormat = WebMessageFormat.Json)]
        public double GetSalesTax(string cityname)
        {
            if (TaxFreeCities.Contains(cityname, StringComparer.CurrentCultureIgnoreCase))
                return 0;
            return (double)cityname.Length / 100;
        }
    }
}