using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Lync.Model.Conversation;
using System.Windows.Media.Imaging;

namespace ReceiverApplication1
{
    public partial class Page : UserControl
    {
        Conversation conversation;
        string AppID = "{add your guid here}";

        public Page()
        {
            InitializeComponent();
            conversation = (Conversation)Microsoft.Lync.Model.LyncClient.GetHostingConversation();
            conversation.ContextDataReceived += new EventHandler<ContextEventArgs>(conversation_ContextDataReceived);
        }

        void conversation_ContextDataReceived(object sender, ContextEventArgs e)
        {
            string data = e.ContextData;
            string ID = e.ApplicationId;
            string type = e.ContextDataType;
            textBox1.Text = type + " " + data.Length.ToString();
            byte[] imageBytes = Convert.FromBase64String(data);
            using (MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
            {
                BitmapImage im = new BitmapImage();
                im.SetSource(ms);
                image1.Source = im;
                image1.Stretch = Stretch.Uniform;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string data = conversation.GetApplicationData(AppID);
            textBox1.Text = data;
        }
    }
}
