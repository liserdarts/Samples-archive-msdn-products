﻿"use strict";

var Wingtip = window.Wingtip || {};

Wingtip.Product = function (id, name, catName) {

    var productId = id,
        categoryName = catName,
        productName = name,

        get_productId = function () { return productId; },
        set_productId = function (v) { productId = v; },
        get_categoryName = function () { return categoryName; },
        set_categoryName = function (v) { categoryName = v; },
        get_productName = function () { return productName; },
        set_productName = function (v) { productName = v; };

    return {
        get_productId: get_productId,
        set_productId: set_productId,
        get_productName: get_productName,
        set_productName: set_productName,
        get_categoryName: get_categoryName,
        set_categoryName: set_categoryName,
    }

};

Wingtip.ProductViewModel = function () {

    var products = ko.observableArray(),
    get_products = function () { return products; },

        load = function () {

            var bcs = new Wingtip.BCS();
            bcs.init("SimpleModel",
                     "Product",
                     "SimpleProductService",
                     "ReadAllProduct");

            bcs.getLobSystemInstances().then(

                //success
                function () {
                    bcs.executeFinder(this.collection).then(

                         //success
                         function () {

                             for (var i = 0; i < this.collection.get_count() ; i++) {
                                 var entityInstance = this.collection.get_item(i);
                                 var fields = entityInstance.get_fieldValues();
                                 products.push(new Wingtip.Product(
                                     fields.Id,
                                     fields.Name,
                                     fields.Category));
                             }

                         },

                         //failure
                         function (args) {
                             alert("Error: " + args.get_message());
                         }

                         );

                },

                //failure
                function (args) {
                    alert("Error: " + args.get_message());
                }
            );
        };

    return {
        load: load,
        get_products: get_products
    }

}();