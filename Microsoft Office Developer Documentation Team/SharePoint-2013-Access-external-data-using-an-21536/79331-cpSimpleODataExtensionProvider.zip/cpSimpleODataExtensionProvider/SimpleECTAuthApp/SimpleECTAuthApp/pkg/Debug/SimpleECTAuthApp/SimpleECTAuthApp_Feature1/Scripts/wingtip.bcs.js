﻿"use strict";

var Wingtip = window.Wingtip || {};

Wingtip.BCS = function () {

    var deferredLobSystemInstances = $.Deferred(),
        deferredFinderResults = $.Deferred(),
        entityNamespace,
        entityName,
        lobSystemInstanceName,
        methodInstanceName,
        ect,
        lob,
        lobi,

        init = function (namespace, entity, system, method) {

            entityNamespace = namespace;
            entityName = entity;
            lobSystemInstanceName = system;
            methodInstanceName = method;

        },

        //LobSystemInstances
        getLobSystemInstances = function () {

            var ctx = SP.ClientContext.get_current();

            ect = ctx.get_web().getAppBdcCatalog().getEntity(entityNamespace, entityName);
            ctx.load(ect);

            lob = ect.getLobSystem();
            ctx.load(lob);

            deferredLobSystemInstances.collection = lob.getLobSystemInstances();
            ctx.load(deferredLobSystemInstances.collection);
            ctx.executeQueryAsync(onLobSystemInstancesSuccess, onLobSystemInstancesError);

            return deferredLobSystemInstances.promise();
        },

        onLobSystemInstancesSuccess = function () {
            deferredLobSystemInstances.resolve();
        },

        onLobSystemInstancesError = function (sender, args) {
            deferredLobSystemInstances.reject(args);
        },

        //Execute the Finder Method
        executeFinder = function (collection) {

            var ctx = SP.ClientContext.get_current();

            for (var i = 0; i < collection.get_count(); i++) {
                if (collection.get_item(i).get_name() === lobSystemInstanceName) {
                    lobi = collection.get_item(i);
                    break;
                }
            }

            var filters = ect.getFilters(methodInstanceName);
            ctx.load(filters);

            deferredFinderResults.collection = ect.findFiltered(filters, methodInstanceName, lobi);
            ctx.load(deferredFinderResults.collection);

            ctx.executeQueryAsync(onExecuteFinderSuccess, onExecuteFinderError);

            return deferredFinderResults.promise();

        },

        onExecuteFinderSuccess = function () {
            deferredFinderResults.resolve();
        },

        onExecuteFinderError = function (sender, args) {
            deferredFinderResults.reject(args);
        };

    return {
        init: init,
        getLobSystemInstances: getLobSystemInstances,
        executeFinder: executeFinder
    }


};