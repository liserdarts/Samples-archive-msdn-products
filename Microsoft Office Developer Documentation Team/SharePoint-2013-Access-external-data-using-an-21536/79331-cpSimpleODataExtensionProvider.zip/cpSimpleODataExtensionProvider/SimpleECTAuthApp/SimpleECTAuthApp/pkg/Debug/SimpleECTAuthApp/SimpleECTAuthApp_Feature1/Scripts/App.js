﻿"use strict";

var Wingtip = Wingtip || {};

Wingtip.AppInit = function () {

    ko.applyBindings(Wingtip.ProductViewModel, document.getElementById("resultsTable"));
    Wingtip.ProductViewModel.load();
}

$(document).ready(function () {

    ExecuteOrDelayUntilScriptLoaded(Wingtip.AppInit, "sp.js");

});