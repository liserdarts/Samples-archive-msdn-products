﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.BusinessData;
using Microsoft.BusinessData.SystemSpecific;
using Microsoft.BusinessData.SystemSpecific.OData;
using System.Security;
using System.Security.Cryptography;

namespace SimpleODataExtensionProvider
{
    public class SimpleTokenExtension : ODataExtensionProvider
    {
        public override void AfterReceiveResponse(System.Net.HttpWebResponse response)
        {
            //not implemented
        }

        public override void BeforeSendRequest(System.Net.HttpWebRequest request)
        {
            const string appId = "{29C57340-EE76-4FCA-B165-33D629C298CE}";
            const string secret = "abc123";

            //Make a simple authorization token
            HMACSHA512 hmac = new HMACSHA512(Encoding.UTF8.GetBytes(secret));
            byte[] hashedAppId = hmac.ComputeHash(Encoding.UTF8.GetBytes(appId));
            string headerAppId = Encoding.UTF8.GetString(hashedAppId);

            //Attach the token top the request
            request.Headers.Add("Authorization", Convert.ToBase64String(Encoding.UTF8.GetBytes(headerAppId)));

        }
    }
}
