﻿using System;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using System.Text;

namespace SimpleSecuredODataSource
{
    [ServiceContract]
    public interface IProducts
    {
        [OperationContract]
        [WebGet (UriTemplate = "products")]
        [ServiceKnownType(typeof(Atom10FeedFormatter))]
        SyndicationFeedFormatter GetProductEntries();

        [OperationContract]
        [WebGet (UriTemplate = "products/{id}")]
        [ServiceKnownType(typeof(Atom10ItemFormatter))]
        SyndicationItemFormatter GetProductEntry(string id);

        [OperationContract]
        [WebGet(UriTemplate = "$metadata")]
        XmlElement GetMetadata();
    }
}
