﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using System.Text;
using System.Security;
using System.Security.Cryptography;

namespace SimpleSecuredODataSource
{
    public class Products : IProducts
    {
        public SyndicationFeedFormatter GetProductEntries()
        {
            if (ValidateToken())
            {
                List<ProductEntry> productEntries = GetProductEntryData();
                List<SyndicationItem> items = new List<SyndicationItem>();

                SyndicationLink link = new SyndicationLink();
                link.RelationshipType = "self";
                link.Uri = new Uri("http://localhost:33668/Products.svc/products");
                link.Title = "Products";

                SyndicationFeed feedData = new SyndicationFeed();
                feedData.Links.Add(link);
                feedData.Id = "http://localhost:33668/Products.svc/products";
                feedData.AttributeExtensions.Add(new XmlQualifiedName("base", "http://www.w3.org/2000/xmlns/"), "http://localhost:33668/Products.svc");
                feedData.AttributeExtensions.Add(new XmlQualifiedName("m", "http://www.w3.org/2000/xmlns/"), "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata");
                feedData.AttributeExtensions.Add(new XmlQualifiedName("d", "http://www.w3.org/2000/xmlns/"), "http://schemas.microsoft.com/ado/2007/08/dataservices");
                feedData.Title = new TextSyndicationContent("Products");
                feedData.Items = items;

                foreach (ProductEntry productEntry in productEntries)
                {
                    SyndicationCategory category = new SyndicationCategory();
                    category.Scheme = "http://schemas.microsoft.com/ado/2007/08/dataservices/scheme";
                    category.AttributeExtensions.Add(new XmlQualifiedName("term"), "SimpleModel.Product");

                    SyndicationItem item = new SyndicationItem();
                    item.Id = productEntry.UrlId;
                    item.Title = new TextSyndicationContent(productEntry.Title);
                    item.BaseUri = new Uri("http://localhost:33668/Products.svc/products");
                    item.LastUpdatedTime = productEntry.CreatedAt;
                    item.PublishDate = productEntry.CreatedAt;
                    item.Authors.Add(new SyndicationPerson() { Name = productEntry.CreatedBy });
                    item.Categories.Add(category);
                    item.ElementExtensions.Add(productEntry.Product.Serialize2Atom());
                    items.Add(item);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/atom+xml";

                return new Atom10FeedFormatter(feedData);
            }
            else
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                WebOperationContext.Current.OutgoingResponse.StatusDescription = "Invalid Token";
                return null;
            }
        }

        public SyndicationItemFormatter GetProductEntry(string id)
        {
            ProductEntry productEntry = GetProductEntryData().Where(p => p.Product.Id == id).FirstOrDefault();

            SyndicationCategory category = new SyndicationCategory();
            category.Scheme = "http://schemas.microsoft.com/ado/2007/08/dataservices/scheme";
            category.AttributeExtensions.Add(new XmlQualifiedName("term"), "SimpleModel.Product");

            SyndicationItem item = new SyndicationItem();
            item.AttributeExtensions.Add(new XmlQualifiedName("m", "http://www.w3.org/2000/xmlns/"), "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata");
            item.AttributeExtensions.Add(new XmlQualifiedName("d", "http://www.w3.org/2000/xmlns/"), "http://schemas.microsoft.com/ado/2007/08/dataservices");

            item.Id = productEntry.UrlId;
            item.Title = new TextSyndicationContent(productEntry.Title);
            item.BaseUri = new Uri("http://localhost:33668/Products.svc/products");
            item.LastUpdatedTime = productEntry.CreatedAt;
            item.PublishDate = productEntry.CreatedAt;
            item.Authors.Add(new SyndicationPerson() { Name = productEntry.CreatedBy });
            item.Categories.Add(category);
            item.ElementExtensions.Add(productEntry.Product.Serialize2Atom());

            WebOperationContext.Current.OutgoingResponse.ContentType = "application/atom+xml";

            return new Atom10ItemFormatter(item);

        }

        private List<ProductEntry> GetProductEntryData()
        {
            return new List<ProductEntry>{
            new ProductEntry() { UrlId = "http://localhost:33668/Products.svc/products/1", Title = "Food Product Entry", Description = "Yummy soup", CreatedAt = DateTime.Now, CreatedBy = "System", Product = new Product { Id="1", Name="Tomato Soup", Category="Groceries",Prices="$1.00"} },
            new ProductEntry() { UrlId = "http://localhost:33668/Products.svc/products/2", Title = "Toy Product Entry", Description = "Classic toy", CreatedAt = DateTime.Now, CreatedBy = "System", Product = new Product { Id="2", Name="Yo-Yo", Category="Toys",Prices="$3.75"} },
            new ProductEntry() { UrlId = "http://localhost:33668/Products.svc/products/3", Title = "Hardware Product Entry", Description = "Useful tool", CreatedAt = DateTime.Now, CreatedBy = "System", Product = new Product { Id="3", Name="Hammer", Category="Hardware",Prices="$16.99"} }
            };
        }

        public XmlElement GetMetadata(){

            XmlDocument xmlDoc = new XmlDocument();

            xmlDoc.LoadXml("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<edmx:Edmx xmlns:edmx=\"http://schemas.microsoft.com/ado/2007/06/edmx\" Version=\"1.0\">" +
                      "<edmx:DataServices m:DataServiceVersion=\"1.0\" xmlns:m=\"http://schemas.microsoft.com/ado/2007/08/dataservices/metadata\">" +
                        "<Schema xmlns:m=\"http://schemas.microsoft.com/ado/2007/08/dataservices/metadata\" " +
                                "xmlns=\"http://schemas.microsoft.com/ado/2008/09/edm\" " +
                                "xmlns:d=\"http://schemas.microsoft.com/ado/2007/08/dataservices\" Namespace=\"SimpleModel\">" +
                          "<EntityType Name=\"Product\">" +
                            "<Key>" +
                              "<PropertyRef Name=\"Id\"/>" +
                            "</Key>" +
                            "<Property Name=\"Id\" Nullable=\"false\" Type=\"Edm.String\" FixedLength=\"false\" Unicode=\"false\" MaxLength=\"5\"/>" +
                            "<Property Name=\"Name\" Nullable=\"false\" Type=\"Edm.String\" FixedLength=\"false\" Unicode=\"false\" MaxLength=\"40\"/>" +
                            "<Property Name=\"Category\" Nullable=\"false\" Type=\"Edm.String\" FixedLength=\"false\" Unicode=\"false\" MaxLength=\"30\"/>" +
                            "<Property Name=\"Prices\" Nullable=\"false\" Type=\"Edm.String\" FixedLength=\"false\" Unicode=\"false\" MaxLength=\"30\"/>" +
                          "</EntityType>" +
                        "</Schema>" +
                        "<Schema xmlns:m=\"http://schemas.microsoft.com/ado/2007/08/dataservices/metadata\" " +
                                "xmlns=\"http://schemas.microsoft.com/ado/2008/09/edm\" " +
                                "xmlns:d=\"http://schemas.microsoft.com/ado/2007/08/dataservices\" " +
                                "Namespace=\"SimpleModelEntities\">" +
                          "<EntityContainer Name=\"SimpleEntities\" " +
                                           "xmlns:p7=\"http://schemas.microsoft.com/ado/2009/02/edm/annotation\" " +
                                           "m:IsDefaultEntityContainer=\"true\" " +
                                           "p7:LazyLoadingEnabled=\"true\">" +
                            "<EntitySet Name=\"Product\" EntityType=\"SimpleModel.Product\"/>" +
                          "</EntityContainer>" +
                        "</Schema>" +
                      "</edmx:DataServices>" +
                    "</edmx:Edmx>");
            return xmlDoc.DocumentElement;

        }

        private bool ValidateToken()
        {
            const string appId = "{29C57340-EE76-4FCA-B165-33D629C298CE}";
            const string secret = "abc123";

            if (WebOperationContext.Current.IncomingRequest.Headers["Authorization"] == null)
                return false;

            //Get the Authorization header
            string incomingAuthAppId = WebOperationContext.Current.IncomingRequest.Headers["Authorization"];

            //Compute the hashed AppId
            HMACSHA512 hmac = new HMACSHA512(Encoding.UTF8.GetBytes(secret));
            byte[] hashedAppId = hmac.ComputeHash(Encoding.UTF8.GetBytes(appId));
            string headerAppId = Encoding.UTF8.GetString(hashedAppId);
            string computedAuthAppId = Convert.ToBase64String(Encoding.UTF8.GetBytes(headerAppId));

            if (!computedAuthAppId.Equals(incomingAuthAppId, StringComparison.OrdinalIgnoreCase))
                return false;

            return true;

        }
    }
}
