﻿using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SimpleSecuredODataSource
{
    public class ProductEntry
    {
        public string UrlId { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }

        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }

        public Product Product { get; set; }
    }

    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Prices { get; set; }

        public XmlReader Serialize2Atom()
        {
            XNamespace a = "http://www.w3.org/2005/Atom";
            XNamespace m = "http://schemas.microsoft.com/ado/2007/08/dataservices/metadata";
            XNamespace d = "http://schemas.microsoft.com/ado/2007/08/dataservices";

            return new XElement(a + "content",
                new XAttribute("type", "application/xml"),
                new XElement(m + "properties",
                    new XAttribute(XNamespace.Xmlns + "m", m),
                    new XElement(d + "Id", Id,
                        new XAttribute(XNamespace.Xmlns + "d", d)),
                    new XElement(d + "Name", Name,
                        new XAttribute(XNamespace.Xmlns + "d", d)),
                    new XElement(d + "Category", Category,
                        new XAttribute(XNamespace.Xmlns + "d", d)),
                    new XElement(d + "Prices", Prices,
                        new XAttribute(XNamespace.Xmlns + "d", d)))).CreateReader();
        }

    }
}