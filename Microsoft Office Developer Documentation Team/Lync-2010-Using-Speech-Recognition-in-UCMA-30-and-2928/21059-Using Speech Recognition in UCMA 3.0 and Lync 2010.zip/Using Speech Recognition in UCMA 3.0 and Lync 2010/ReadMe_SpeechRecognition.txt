ChooseFlight Speech Recognition Application:
UCMA application - ChooseFlight.zip
Lync application - FlightChooser.zip
Reg export - ChooseFlight.reg

The HTML, logo, and .xap files for the Micrsoft Lync 2010 application are in wwwroot*.zip. These files must be available when the Lync Conversation Window Extension opens.



