﻿using System;

namespace Microsoft.Rtc.Collaboration.Sample.Common
{
    /// <summary> 
    /// Encoding Types. 
    /// </summary> 
    public enum EncodingType
    {
        ASCII,
        Unicode,
        UTF7,
        UTF8,
        UTF32
    }
    class Converter
    {
        
        /// <summary> 
        /// Converts a byte array to a string using Unicode encoding. 
        /// </summary> 
        /// <param name="bytes">The byte array to be converted.</param> 
        /// <returns>A string whose contents are the converted elements of the byte[].</returns> 
        public static string ConvertByteArrayToString(byte[] byteArray)
        {
            return ConvertByteArrayToString(byteArray, EncodingType.Unicode);
        }


        /// <summary> 
        /// Converts a byte array to a string using specified encoding. 
        /// </summary> 
        /// <param name="byteArray">The byte array to be converted.</param> 
        /// <param name="encodingType">A member of the EncodingType enumeration.</param> 
        /// <returns>string</returns> 
        public static System.String ConvertByteArrayToString(byte[] byteArray, EncodingType encodingType) 
        { 
            System.Text.Encoding encoding = null; 
            if (encodingType == EncodingType.ASCII)
                encoding = new System.Text.ASCIIEncoding();
            else if (encodingType == EncodingType.Unicode)
                encoding = new System.Text.UnicodeEncoding();
            else if (encodingType == EncodingType.UTF7)
                encoding = new System.Text.UTF7Encoding();
            else if (encodingType == EncodingType.UTF8)
                encoding = new System.Text.UTF8Encoding();
            else if (encodingType == EncodingType.UTF32)
                encoding = new System.Text.UTF32Encoding();
            if (!(encoding == null))
            {
                return encoding.GetString(byteArray);
            }
            else return "Bad encoding type.";
        }
    }
}




