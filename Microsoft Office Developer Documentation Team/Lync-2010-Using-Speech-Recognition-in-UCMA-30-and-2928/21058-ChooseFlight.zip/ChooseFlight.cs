﻿using System;
using System.Threading;
using System.Text;
using Microsoft.Rtc.Collaboration;
using Microsoft.Rtc.Collaboration.AudioVideo;
using Microsoft.Rtc.Signaling;
using Microsoft.Rtc.Collaboration.Sample.Common;
using Microsoft.Speech.AudioFormat;
using Microsoft.Speech.Recognition;
using System.Net.Mime;
using System.Collections.Generic;



namespace Microsoft.Rtc.Collaboration.Sample.ChooseFlight
{
  // This UCMA application creates an outbound audio-video call to a remote Lync 2010 user, and opens the Lync Extensibility 
  // window. This application also creates a SpeechRecognitionEngine instance so that semantic information from 
  // the remote user's speech can be recognized and displayed in a form on the Lync user's computer screen.
  // Communication between the UCMA application and the remote Lync 2010 application occurs via audio from the Lync application
  // to the UCMA application, and in both directions via a ConversationContextChannel instance. After the context channel is established, 
  // the UCMA application sends contextual data to the remote user, notifying the user to speak his or her preferences for a desired flight. 
  // The audio of this utterance is fed into a SpeechRecognitionEngine and matched against an SRGS XML grammar. If a match 
  // occurs, the UCMA application sends a string containing the flight origination and destination, and the cost of a
  // ticket. The Lync user shuts down both applications by clicking the Exit button in the form that appears in the Extensibility window.
  // After this application ends the call, it shuts down the platform and ends, and then pauses the console to allow logs to be viewed.
  // The UCMA application logs in as UserName1, given in App.config, and places an audio-video call to the target user, CalledParty,
  // also given in App.config.
 
  public class ChooseFlightAVCall
  {
    // Some necessary instance variables.
    private CollaborationPlatform _collabPlatform;
    private AudioVideoCall _audioVideoCall;
    private AudioVideoFlow _audioVideoFlow;
  
    // The conversation.
    private Conversation _conversation;
 
    // The conversation context channel.
    private ConversationContextChannel _channel;

    // The speech recognition engine.
    SpeechRecognitionEngine _speechRecognitionEngine;
    
  
    // Wait handles are present only to keep things synchronous and easy to read.
    private AutoResetEvent _waitForRecoCompleted = new AutoResetEvent(false);
    private AutoResetEvent _waitForGrammarToLoad = new AutoResetEvent(false);
    private AutoResetEvent _waitForPlatformShutdownCompleted = new AutoResetEvent(false);

    static void Main(string[] args)
    {
      ChooseFlightAVCall BasicAVCall= new ChooseFlightAVCall();
      BasicAVCall.Run();
    }

    public void Run()
    {
      // Create an AudioVideoFlow instance.
      AudioVideoFlowHelper audioVideoFlowHelper = new AudioVideoFlowHelper();
      _audioVideoFlow = audioVideoFlowHelper.CreateAudioVideoFlow(null, audioVideoFlow_StateChanged);

      _audioVideoCall = _audioVideoFlow.Call;
      _conversation = _audioVideoCall.Conversation;
      _collabPlatform = _conversation.Endpoint.Platform;

      // Create the context channel. 
      _channel = new ConversationContextChannel(_conversation, _audioVideoCall.RemoteEndpoint);

      // Register handlers for the DataReceived and StateChanged events on ConversationContextChannel.
      _channel.DataReceived += new EventHandler<ConversationContextChannelDataReceivedEventArgs>(channel_DataReceived);
      _channel.StateChanged += new EventHandler<ConversationContextChannelStateChangedEventArgs>(channel_StateChanged);

      // Create a speech recognition connector and attach it to the AudioVideoFlow instance.
      SpeechRecognitionConnector speechRecognitionConnector = new SpeechRecognitionConnector();
      speechRecognitionConnector.AttachFlow(_audioVideoFlow);

      // Start the speech recognition connector.
      SpeechRecognitionStream stream = speechRecognitionConnector.Start();

      // Create a SpeechRecognitionEngine and register for event notification.
      _speechRecognitionEngine = new SpeechRecognitionEngine();
      _speechRecognitionEngine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(speechRecognitionEngine_SpeechRecognized);
      _speechRecognitionEngine.LoadGrammarCompleted += new EventHandler<LoadGrammarCompletedEventArgs>(speechRecognitionEngine_LoadGrammarCompleted);

      // Create a Grammar object and load it into the SpeechRecognitionEngine.
      String currDirPath = Environment.CurrentDirectory + "\\Airports.grxml";
      Grammar gr = new Grammar(currDirPath, "Main");
      _speechRecognitionEngine.LoadGrammarAsync(gr);
      _waitForGrammarToLoad.WaitOne();

      // Connect the audio stream to the SpeechRecognitionEngine.
      SpeechAudioFormatInfo speechAudioFormatInfo = new SpeechAudioFormatInfo(8000, AudioBitsPerSample.Sixteen, Microsoft.Speech.AudioFormat.AudioChannel.Mono);
      _speechRecognitionEngine.SetInputToAudioStream(stream, speechAudioFormatInfo);
      
      // Configure a set of options for a context channel.
      ConversationContextChannelEstablishOptions channelOptions = ConfigureChannelOptions();
      
      // The Application ID.
      // This GUID is used by this application and the Lync 2010 application. 
      // A key with this title must be present in the registry
      // under HKLM\SOFTWARE\Policies\Microsoft\Communicator\ContextPackages\.
      Guid guid = new Guid("C17C216F-04A9-4234-94C1-A2EA5F0C4873");
     
      // Establish a context channel to the remote endpoint.
      IAsyncResult result = _channel.BeginEstablish(guid, channelOptions, BeginEstablishCB, _channel);

      // Block this thread until recognition is complete.
      _waitForRecoCompleted.WaitOne();
         
      // Stop the connector.
      speechRecognitionConnector.Stop();
      Console.WriteLine("Stopping the speech recognition connector.");

      result = _channel.BeginTerminate(BeginTerminateCB, _channel);
      _waitForPlatformShutdownCompleted.WaitOne();

      // Pause the console to allow the user to view logs.
      Console.WriteLine("Press any key to end the sample.");
      Console.ReadKey();  
    }


    #region EVENT HANDLERS
  
    // Event handler to record the call state transitions in the console.
    void audioVideoCall_StateChanged(object sender, CallStateChangedEventArgs e)
    {
      Console.WriteLine("Call has changed state. Previous state: " + e.PreviousState + " Current state: " + e.State);
    }

    // Event handler for the StateChanged event on the channel. 
    void channel_StateChanged(object sender, ConversationContextChannelStateChangedEventArgs e)
    {
      Console.WriteLine("Channel state change reason: {0}", e.TransitionReason.ToString());
      Console.WriteLine("New channel state: {0}", _channel.State.ToString());
    }

    // Flow created indicates that there is a flow present to begin media operations with, and that it is no longer null.
    public void audioVideoCall_FlowConfigurationRequested(object sender, AudioVideoFlowConfigurationRequestedEventArgs e)
    {
      Console.WriteLine("Flow Created.");
      _audioVideoFlow = e.Flow;

      // Now that the flow is non-null, bind the event handler for State Changed.
      // When the flow goes active, (as indicated by the state changed event) the application can take media-related actions on the flow.
      _audioVideoFlow.StateChanged += new EventHandler<MediaFlowStateChangedEventArgs>(audioVideoFlow_StateChanged);
    }

    
    // Event handler for the DataReceived event on ConversationContextChannel. 
    // The only data expected is "exit".
    void channel_DataReceived(object sender, ConversationContextChannelDataReceivedEventArgs e)
    {
      // Assume that no more than 10 bytes are sent at a time.
      Byte[] body_byte = new Byte[10];
      body_byte = e.ContentDescription.GetBody();
      
      String body_UTF8 = null;
      body_UTF8 = Converter.ConvertByteArrayToString(body_byte, EncodingType.UTF8);

      if (body_UTF8.Equals("exit"))
      {
        _waitForRecoCompleted.Set();
        _speechRecognitionEngine.RecognizeAsyncStop();
      }
      else
      {
        Console.WriteLine("Unexpected results received in channel_DataReceived()");
      }
    }

    // Event handler for the LoadGrammarCompleted event on the SpeechRecognitionEngine.
    void speechRecognitionEngine_LoadGrammarCompleted(object sender, LoadGrammarCompletedEventArgs e)
    {
      Console.WriteLine("Grammar is now loaded.");
      _waitForGrammarToLoad.Set();
    }

    // Event handler for the SpeechRecognized event on the SpeechRecognitionEngine.
    void speechRecognitionEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
    {
      RecognitionResult recoResult = e.Result;
      String str; 
      String origCity, destCity;
      String[] prices = new String[4] { "$368.00", "$429.00", "$525.00", "$631.00" };
      int idx;
      Random rand = new Random();
      
      if (recoResult != null)
      {
        Console.WriteLine("Speech recognized: " + recoResult.Text);
        origCity = recoResult.Semantics["Origination"].Value.ToString();
        destCity = recoResult.Semantics["Destination"].Value.ToString();
        str = origCity;
        str = String.Concat(str, ";");
        str = String.Concat(str, destCity);
        str = String.Concat(str, ";");
        
        // The (bogus) cost of the flight.
        idx = rand.Next(0, 3);
        str = String.Concat(str, prices[idx]);
        SendDataToRemote(str);
      }
    }
    #endregion 


    #region HELPER METHODS
    /// <summary>
    /// Sends the given data to the remote side of the channel. The data to be sent must be converted
    /// to an array of type Byte.
    /// </summary>
    /// <param name="data">A String to be sent on the context channel.</param>
    private void SendDataToRemote(String data)
    {
      // Each string to be sent consists of three fields, separated by semicolons.
      
      int len = data.Length;

      // Convert temp to Byte[].
      Byte[] data_bytes = new byte[data.Length];

      for (int i = 0; i < len; i++)
      {
        data_bytes[i] = Convert.ToByte(data[i]);
      }

      ContentType contentType = new ContentType("text/plain; charset=us-ascii");

      _channel.BeginSendData(contentType, data_bytes, BeginSendDataCB, _channel);
    }

    ///<summary>Configure options for a ConversationContextChannel instance.
    ///</summary>
    ConversationContextChannelEstablishOptions ConfigureChannelOptions()
    {
      ConversationContextChannelEstablishOptions channelOptions = new ConversationContextChannelEstablishOptions();
      channelOptions.ApplicationInstallerPath = ""; // Used when the remote-side application is not already installed.
      channelOptions.ApplicationName = "Wild Blue Yonder Airlines";
      channelOptions.ContextualData = "Context channel is open."; // Normally used for initialization.
      channelOptions.Toast = "Get ready for incoming contextual data.";
      return channelOptions;
    }

    #endregion


    #region CALLBACK METHODS

    // Callback for BeginEstablish on ConversationContextChannel.
    private void BeginEstablishCB(IAsyncResult result)
    {
      ConversationContextChannel channel = result.AsyncState as ConversationContextChannel;

      try
      {
        channel.EndEstablish(result);
        // Give the Lync 2010 client some time to get the UI in order. 
        Thread.Sleep(250);
      }

      catch (Exception ex)
      {
        Console.WriteLine("EndEstablish exception: " + ex);
      }

      Console.WriteLine("BeginEstablish IAsyncResult.IsCompleted: {0}", result.IsCompleted.ToString());
      _speechRecognitionEngine.RecognizeAsync(RecognizeMode.Multiple);
    }


    // Callback for BeginSendData on ConversationContextChannel.
    private void BeginSendDataCB(IAsyncResult ar)
    {
      ConversationContextChannel channel = ar.AsyncState as ConversationContextChannel;
      channel.EndSendData(ar);
      Console.WriteLine("\nEndSendData() called on channel. IAsyncResult.IsCompleted value: {0}.", ar.IsCompleted.ToString());
    }

    // Callback for BeginTerminate on ConversationContextChannel.
    private void BeginTerminateCB(IAsyncResult ar)
    {
      ConversationContextChannel channel = ar.AsyncState as ConversationContextChannel;

      // Complete the termination of the context channel.
      channel.EndTerminate(ar);

      // Terminate the call. 
      IAsyncResult result = _audioVideoCall.BeginTerminate(EndTerminateCall, _audioVideoCall);
      Console.WriteLine("Waiting for the call to be terminated...");
    }

    private void EndTerminateCall(IAsyncResult ar)
    {
      AudioVideoCall AVCall = ar.AsyncState as AudioVideoCall;

      // Complete the termination of the incoming call.
      AVCall.EndTerminate(ar);

      // Terminate the conversation.
      IAsyncResult result = _audioVideoCall.Conversation.BeginTerminate(EndTerminateConversation, _audioVideoCall.Conversation);
      Console.WriteLine("Waiting for the conversation to be terminated...");
    }

    private void EndTerminateConversation(IAsyncResult ar)
    {
      Conversation conv = ar.AsyncState as Conversation;

      // Complete the termination of the conversation.
      conv.EndTerminate(ar);

      // Now, clean up by shutting down the platform.
      Console.WriteLine("Shutting down the platform...");

      _collabPlatform.BeginShutdown(PlatformShutdownCB, _collabPlatform);
    }

    // Callback that handles the StateChanged event on an AudioVideoFlow instance.
    private void audioVideoFlow_StateChanged(object sender, MediaFlowStateChangedEventArgs e)
    {
      // When flow is active, media operations can begin.
      if (e.State == MediaFlowState.Terminated)
      {
        // Detach SpeechRecognitionConnector since AVFlow is now terminated.
        AudioVideoFlow avFlow = (AudioVideoFlow)sender;
        if (avFlow.SpeechRecognitionConnector != null)
        {
          avFlow.SpeechRecognitionConnector.DetachFlow();
        }
      }
    }
    

    private void PlatformShutdownCB(IAsyncResult ar)
    {
      CollaborationPlatform collabPlatform = ar.AsyncState as CollaborationPlatform;
      try
      {
        // Shutdown actions will not throw.
        collabPlatform.EndShutdown(ar);
        Console.WriteLine("The platform is now shut down.");
      }
      finally
      {
        _waitForPlatformShutdownCompleted.Set();
      }
    }

    #endregion

  }
}
