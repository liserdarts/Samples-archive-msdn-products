﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Runtime.Serialization;
using Microsoft.SharePoint.Phone.Application;
using Microsoft.SharePoint.Client;
using System.Collections.ObjectModel;

namespace SP_AutohostedExpensesMobile_cs
{
    [DataContract]
    public class DesignEditItemViewModel : EditItemViewModelBase
    {
        /// <summary>
        /// Provides edit values for fields of the List, given its name. Also used for data binding to Edit form UI
        /// </summary>
        public DesignEditItemViewModel()
        {

            //Title
            this["Title"] = "Sample Text";

            //Amount
            this["Amount"] = "$123";

        }

        /// <summary>
        /// Provides edit values for fields of the List, given its name. Also used for data binding to Edit form UI
        /// </summary>
        /// <param name="fieldName" />
        /// <returns />
        public override object this[string fieldName]
        {
            get
            {
                return base[fieldName];
            }
            set
            {
                base[fieldName] = value;
            }
        }
    }
}
