﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SP_AutohostedExpenses_csWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var contextToken = TokenHelper.GetContextTokenFromRequest(Page.Request);
            var hostWeb = Page.Request["SPHostUrl"];

            using (var clientContext = TokenHelper.GetClientContextWithContextToken(hostWeb, contextToken, Request.Url.Authority))
            {
                clientContext.Load(clientContext.Web);
                clientContext.ExecuteQuery();
                // Redirect the browser experiense to the Expenses List that is deployed
                // with this App. The point is that the separate SP_AutohostedExpensesMobile_cs
                // Windows Phone App will then use the Expenses list to allow users to view, add, edit,
                // and delete expense items from the mobile UI.
                Response.Redirect(clientContext.Web.Url 
                    + "/SP_AutohostedExpenses_cs/Lists/Expenses/AllItems.aspx");
               
            }
        }
    }
}