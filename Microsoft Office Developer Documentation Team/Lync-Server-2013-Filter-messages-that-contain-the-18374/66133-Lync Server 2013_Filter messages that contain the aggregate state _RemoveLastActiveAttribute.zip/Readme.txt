The RemoveLastActiveAttribute script-only application, written in MSPL, illustrates how to filter messages containing the aggreate state as represented by the enhanced presence state category instance and modify the message content to remove any lastActive attributes. The effect of the operation is to disable the display of the time duration of certain presence states, such as Away. The process allows a Lync server administrator to enable custom privacy settings so that the default Lync display of "Away 10 mins" is altered to "Away".

The application consists of the following files:
	0. Readme.txt: this file.
	1. RemoveLastActiveAttribute.am: the application manifest file with the MSPL script.
	2. CompileSpl.bat: a DOS command file for compiling the applicaiton manifest and the script.
	3. RegisterLyncServerApp.ps1: the Windows PowerShell command script to register the app. You will need to replace the <lync-server-name> with the name of your Lync Server Front End.
	4. UnregisterLyncserverApp.ps1: the Windows powerShell command script to unregister the app.

To run the application, do the following:
	0. Install Microsoft Lync Server 2013 Server SDK, on a Lync Server computer where this app is to run.
	1. Run the CompileSpl.bat file in a Windows Command console to ensure the script can be successfully compiled. 
	2. Run the RegisterLyncServerApp.ps1 file in a Lync Server Management Shell console from a user account in the RTC Server Applications local security group.
	3. Start or refresh Lync to see that the status duration should become absent for the Away and other approrpriate states. (You need to have one of the contact status set as Away for more than 5 minutes.)
	4. Run the UnRegisterLyncServerApp.ps1 file in a Lync server Management Shell console to unregister the application.
	5. Watch the time duration reappears (e.g., "Away 5 mins") in the Lync client.
        6. You can use Windows Event Viewer to the Log output. For more information on using the Windows Event Viewer, see the Microsoft Lync Server 2013 SDK documentation.


