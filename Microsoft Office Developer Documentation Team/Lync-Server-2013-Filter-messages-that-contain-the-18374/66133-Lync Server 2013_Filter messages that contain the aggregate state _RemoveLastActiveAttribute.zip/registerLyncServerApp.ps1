copy RemoveLastActiveAttribute.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.contoso.com/RemoveLastActiveAttribute" -identity "service:registrar:<lync-sever-fqdn>/RemoveLastActiveAttribute" -critical $false -priority 5 -scriptname RemoveLastActiveAttribute.am -enabled $true

invoke-csManagementStoreReplication