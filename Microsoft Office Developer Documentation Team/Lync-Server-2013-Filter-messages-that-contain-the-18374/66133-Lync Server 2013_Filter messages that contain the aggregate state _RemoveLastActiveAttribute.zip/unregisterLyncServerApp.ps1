remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/RemoveLastActiveAttribute"

del 'C:\Program Files\Microsoft Lync server 15\server\Core\RemoveLastActiveAttribute.am'

invoke-csManagementStoreReplication

