copy ApplicationStamping.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.microsoft.com/LC/SDK/Samples/ApplicationStamping" -identity "service:registrar:<lync-sever-fqdn>/ApplicationStamping" -critical $false -priority 5 -scriptname ApplicationStamping.am -enabled $true

invoke-csManagementStoreReplication