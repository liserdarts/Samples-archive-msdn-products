===========================================================================

    Microsoft Lync Server 2013, SDK Samples

    Copyright (c) Microsoft Corporation.  All rights reserved.

===========================================================================


Sample Description
------------------

 ApplicationStamping is an SPL script that demonstrates setting and
 retrieving message stamps.  Stamping is a mechanism by which applications
 tag a message with a string, allowing communication with other instances 
 of the same application on other servers in a topology.  Stamp data is 
 only visible to applications with the same application URI, and does
 not cross edge servers.
 
 This sample demonstrates:

 - Detecting existing stamp data
 - Setting a new stamp on a request
 - Changing an existing message stamp

Application Installation
------------------------
 To install and run the sample, you will need the following software:
 
 - Windows 2003 Server SP2 and above.
 - Microsoft Lync Server 2013 Home Server
 - Microsoft Lync Server 2013, SDK
 - Two (2) Microsoft Lync 2013 clients.

 - Install the application by running the RegisterLyncServerApp.ps1 from a 
   Lync Server Management Shell console. 
 - Uninstall the applicaiton by running the UnregisterLyncServerApp.ps1 from
   a Lync Server Management Shell console.

   Make sure to update the <lync-server-fqdn> placeholder in the PS script 
   to the FQDN of your Lync Server (pool).

 
Running this Sample
-------------------

 Log each user into its homeserver, using the clients.  Send IMs
 in both directions, then view the ApplicationStamping output in the APILogger
 windows.  A successful run will produce output similar to


    Entering ApplicationStamping.am.
      Received unstamped request: MESSAGE; stamping
      Proxying.

    Entering ApplicationStamping.am.
      Received stamped request: MESSAGE
        Stamped by: server2.myhost.com
        Stamp data: "Stamped by ApplicationStamping.am on server1.myhost.com." 
      Modifying stamp.
      Proxying.

    Entering ApplicationStamping.am.
      Received stamped request: NOTIFY
        Stamped by: server2.myhost.com
        Stamp data: "Stamped by ApplicationStamping.am on server1.myhost.com."
      Modifying stamp.
      Proxying.


File List
---------

 ApplicationStamping.am

