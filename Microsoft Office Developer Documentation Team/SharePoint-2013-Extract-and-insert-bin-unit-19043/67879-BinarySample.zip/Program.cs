﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace BinUnitExtractInsertTool
{
    /// <summary>
    /// The class which will extract and insert bin-unit files from a specified XLIFF file.
    /// </summary>
    public class BinUnitExtractInsertTool
    {
        /// <summary>
        /// The program entry point.
        /// </summary>
        /// <param name="args">Array of command line arguments.</param>
        public static void Main(string[] args)
        {
            if (args.Length > 1)
            {
                string operation = args[0];
                string xliffFilePath = args[1];
                string workingDirectory = (args.Length > 2) ? args[2] : string.Empty;
                // Determine the operation to execute, either extract or insert.
                if (operation == "extract")
                {
                    if (string.IsNullOrWhiteSpace(workingDirectory))
                        workingDirectory = "Extracted";
                    BinUnitExtractInsertTool.Extract(xliffFilePath, workingDirectory);
                }
                else if (operation == "insert")
                {
                    if (string.IsNullOrWhiteSpace(workingDirectory))
                        workingDirectory = "Insert";
                    BinUnitExtractInsertTool.Insert(xliffFilePath, workingDirectory);
                }
                else
                {
                    Console.WriteLine(HelpMessage);
                }
            }
            else
            {
                Console.WriteLine(HelpMessage);
            }
        }

        /// <summary>
        /// Opens the specified XLIFF file and extracts all bin-source elements into the Extracted subfolder of the present
        /// working directory. If the Extracted subfolder doesn't exist, it will be created.
        /// </summary>
        /// <param name="xliffPath">The path to the XLIFF file to extract bin-sources from.</param>
        private static void Extract(string xliffPath, string workingDirectoryPath)
        {
            using (XmlReader reader = XmlReader.Create(xliffPath))
            {
                BinUnitExtractInsertTool.Initialize(workingDirectoryPath, reader);

                XmlNodeList xliffFileNodes = xliffDocument.DocumentElement.SelectNodes(XliffXmlName + ":file", namespaceManager);
                // Iterate over all the <file> nodes.
                foreach (XmlNode xliffFileNode in xliffFileNodes)
                {
                    string extractedFileRelativePath = GetFileName(xliffFileNode, namespaceManager, workingDirectory);
                    XmlNode bodyNode = xliffFileNode.SelectSingleNode(XliffXmlName + ":body", namespaceManager);
                    XmlNodeList binUnitSubFields = bodyNode.SelectNodes(XliffXmlName + ":bin-unit", namespaceManager);
                    // Iterate over all the <bin-unit> nodes if they exist.
                    foreach (XmlNode xliffBinUnitNode in binUnitSubFields)
                    {
                        XmlNode binSourceNode = xliffBinUnitNode.SelectSingleNode(XliffXmlName + ":bin-source", namespaceManager);
                        XmlNode internalFileNode = binSourceNode.SelectSingleNode(XliffXmlName + ":internal-file", namespaceManager);

                        byte[] internalFileContent = GetInternalFileContent(internalFileNode.InnerText);

                        using (FileStream fileStream = new FileStream(extractedFileRelativePath, FileMode.Create))
                        using (BinaryWriter writer = new BinaryWriter(fileStream))
                        {
                            writer.Write(internalFileContent);
                            writer.Close();
                        }
                        Console.WriteLine(string.Format("Successfully extracted file: {0}", extractedFileRelativePath));
                    }
                }
            }
        }

        /// <summary>
        /// Identifies bin-unit elements in an XLIFF file and inserts target elements from the Insert subdirectory. If the XLIFF package was 
        /// previously extracted using this tool, you can rename the Extracted subdirectory to Insert after translating the content. This process
        /// will produce a file in the present working directory called for-import.xlf.
        /// </summary>
        /// <param name="xliffPath">The path to the XLIFF file used to identify bin-units.</param>
        /// <param name="workingDirectoryPath">The directory from which to insert files.</param>
        private static void Insert(string xliffPath, string workingDirectoryPath)
        {
            using (XmlReader reader = XmlReader.Create(xliffPath))
            {
                BinUnitExtractInsertTool.Initialize(workingDirectoryPath, reader);

                XmlNodeList xliffFileNodes = xliffDocument.DocumentElement.SelectNodes(XliffXmlName + ":file", namespaceManager);
                // Iterate over all the <file> nodes.
                foreach (XmlNode xliffFileNode in xliffFileNodes)
                {
                    string fileToInsertPath = BinUnitExtractInsertTool.GetFileName(xliffFileNode, namespaceManager, workingDirectory);

                    if (File.Exists(fileToInsertPath))
                    {
                        XmlNode bodyNode = xliffFileNode.SelectSingleNode(XliffXmlName + ":body", namespaceManager);
                        XmlNodeList binUnitSubFields = bodyNode.SelectNodes(XliffXmlName + ":bin-unit", namespaceManager);

                        // Iterate over all the <file> nodes.
                        foreach (XmlNode xliffBinUnitNode in binUnitSubFields)
                        {
                            string internalFileContent = CreateInternalFileContent(fileToInsertPath);
                            XmlElement internalFileElement = xliffDocument.CreateElement("internal-file", XmlnsXml);

                            internalFileElement.InnerText = internalFileContent;

                            XmlElement binTargetElement = xliffDocument.CreateElement("bin-target", XmlnsXml);
                            binTargetElement.AppendChild(internalFileElement);
                            xliffBinUnitNode.AppendChild(binTargetElement);

                            Console.WriteLine(string.Format("Successfully inserted file: {0}", fileToInsertPath));
                        }
                    }
                }

                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.NewLineHandling = NewLineHandling.Entitize;
                using (XmlWriter writer = XmlWriter.Create("for-import.xlf", settings))
                {
                    xliffDocument.Save(writer);
                }
            }
        }

        private static void Initialize(string workingDirectoryPath, XmlReader reader)
        {
            workingDirectory = Directory.CreateDirectory(workingDirectoryPath);

            xliffDocument = new XmlDocument();
            xliffDocument.Load(reader);

            namespaceManager = new XmlNamespaceManager(xliffDocument.NameTable);
            namespaceManager.AddNamespace(XliffXmlName, XmlnsXml);
        }

        /// <summary>
        /// Internal-file elements store data in Base64 format. Opens the file at the given path and transforms its content into a base64 string.
        /// </summary>
        /// <param name="pathToFile">Path to the file to read content from</param>
        /// <returns>A Base64 encoded string of the file's content.</returns>
        private static string CreateInternalFileContent(string pathToFile)
        {
            string content = string.Empty;

            using (FileStream fileStream = new FileStream(pathToFile, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(fileStream))
            {
                byte[] bytes = reader.ReadBytes((Int32)fileStream.Length);
                content = Convert.ToBase64String(bytes);
            }
            return content;
        }

        /// <summary>
        /// Internal-file elements store data in Base64 format. Converts the Base64 content into a string representation of the data.
        /// </summary>
        /// <param name="base64FileContent">The contents of an internal-file element, encoded in Base64.</param>
        /// <returns>A string of data to write to a file.</returns>
        private static byte[] GetInternalFileContent(string base64FileContent)
        {
            if (string.IsNullOrWhiteSpace(base64FileContent))
                return new byte[0];

            return Convert.FromBase64String(base64FileContent);
        }

        /// <summary>
        /// Gets the value of a url note element from an XLIFF <file /> node. This represents the path of the file relative to the root of the list it was exported from.
        /// </summary>
        /// <param name="xliffFileNode">The XLIFF <file /> node to infer a path from.</param>
        /// <param name="operationDirectory">The directory the operation (either export or insert) is working in.</param>
        /// <returns>The fully formed path to the file. This is used by Extract and Infer to determine where to place the file or what file to read from respectively.</returns>
        private static string GetFileName(XmlNode xliffFileNode, XmlNamespaceManager namespaceManager, DirectoryInfo operationDirectory)
        {
            XmlNode headerNode = xliffFileNode.SelectSingleNode(XliffXmlName + ":header", namespaceManager);
            XmlNodeList noteNodes = headerNode.SelectNodes(XliffXmlName + ":note", namespaceManager);
            if (noteNodes.Count > 0)
            {
                // Iterate over all the <note> nodes.
                foreach (XmlNode noteNode in noteNodes)
                {
                    string noteNodeValue = noteNode.InnerText;
                    if (noteNodeValue.StartsWith(UrlPrefix, StringComparison.OrdinalIgnoreCase))
                    {
                        //URLs use the backward-slash character (/) as path separators, while windows uses the forward-slash character (\)
                        //StreamWriter is smart enough to properly concatinate these.
                        int fileNameStartIndex = noteNodeValue.LastIndexOf("/") + 1;

                        //If there is a path separator, we must create the subdirectory or subdirectories. If not, grab everything after the 'url=' prefix.
                        if (fileNameStartIndex != 0)
                        {
                            DirectoryInfo extractedSubdirectory = Directory.CreateDirectory(
                                operationDirectory.FullName + @"\" + noteNodeValue.Substring(UrlPrefix.Length, fileNameStartIndex - UrlPrefix.Length));
                            return extractedSubdirectory.FullName + @"\" + noteNodeValue.Substring(fileNameStartIndex);
                        }
                        else
                        {
                            return noteNodeValue.Substring(UrlPrefix.Length);
                        }
                    }
                }
            }
            throw new InvalidOperationException("File does not contain the required url note.");
        }

        private static DirectoryInfo workingDirectory;
        private static XmlDocument xliffDocument;
        private static XmlNamespaceManager namespaceManager;

        private const string HelpMessage =
@"BinUnitExtractInsertTool Usage:
BinUnitExtractInsertTool.exe <Operation> <XLIFF File> [<Working Directory>]

<Operation>: Either 'extract' or 'insert'. 
    Extract will undo the Base64 encoding of all the <internal-file> elements in <XLIFF File> and place them in <Working Directory>. If <Working Directory> is not specified, it will default to the Extracted subdirectory.
    Insert will identify all the <internal-file> elements in <XLIFF File>, search <Working Directory> (or the Insert subdirectory if it's not specified) or then insert them into a new XLIFF file called for-import.xlf.

<XLIFF File>: Path to an XLIFF file created by SharePoint.

<Working Directory>: The directory in which to extract files to or insert them from.

Examples:
BinarySample.exe extract sample.xlf
BinarySample.exe extract sample.xlf Subdirectory
BinarySample.exe insert sample.xlf
BinarySample.exe insert sample.xlf Subdirectory";

        private const string UrlPrefix = "url=";
        private const string XliffXmlName = "xliff";
        private const string XmlnsXml = "urn:oasis:names:tc:xliff:document:1.2";
    }
}
