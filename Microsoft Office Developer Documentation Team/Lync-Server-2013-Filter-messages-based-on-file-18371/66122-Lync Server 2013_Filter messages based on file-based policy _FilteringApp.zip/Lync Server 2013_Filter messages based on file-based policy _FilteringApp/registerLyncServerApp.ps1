copy Filter.am 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'
copy Policy.txt 'C:\Program Files\Microsoft Lync server 2013\server\Core\.'

new-csServerApplication -uri "http://www.microsoft.com/LC/SDK/Samples/Filter" -identity "service:registrar:<lync-sever-fqdn>/FilteringApp" -critical $false -priority 5 -scriptname Filter.am -enabled $true

invoke-csManagementStoreReplication