
===========================================================================

    Microsoft Lync Server 2013, SDK Samples

    Copyright (c) Microsoft Corporation.  All rights reserved.

===========================================================================

Sample Description
------------------

 Filter is a script that demonstrates the use of flat-file access in SPL.  
 A user-based policy file (policy.txt) describes the action to take on
 requests destined for specific users, and the script proxies, filters, or
 rejects messages based on the configuration in policy.txt.

 Policy.txt is a whitespace-delimited text file formatted in three columns:

    user@host       policy      value

 where <user@host> is the URI of the (destination) user for the policy, 
 <policy> is one of "allow," "filter," or "drop," and <value> is a string
 used to pass additional information to the filter.

 The "allow" policy proxies all messages to the recipient.  "filter" will
 proxy all messages not containing the string set in the <value> column,
 and "drop" drops all messages destined to user@host.

 The policy.txt file is reloaded whenever modified.

 This sample demonstrates:

 - Flat-file access.
 

Application Installation
------------------------
 To install and run the sample, you will need the following software:
 
 - Windows 2003 Server SP2 and above.
 - Microsoft Lync Server 2013 Home Server
 - Microsoft Lync Server 2013, SDK
 - Two (2) Microsoft Lync 2013 clients.

 - Install the application by running the RegisterLyncServerApp.ps1 from a 
   Lync Server Management Shell console.
 - Uninstall the applicaiton by running the UnregisterLyncServerApp.ps1 from
   a Lync Server Management Shell console.

   Make sure to update the <lync-server-fqdn> placeholder in the PS script 
   to the FQDN of your Lync Server (pool).
 
Running this Sample
-------------------

 Edit policy.txt to reflect the addresses of the two clients
 you'll be using to run this sample.  (Note that the addresses must be in
 user@FQDN form.)

 Log each user into its homeserver, using the clients.  Send IMs
 in both directions, and change values in policy.txt to affect the behavior
 of the message filter.


File List
---------

 Filter.am

