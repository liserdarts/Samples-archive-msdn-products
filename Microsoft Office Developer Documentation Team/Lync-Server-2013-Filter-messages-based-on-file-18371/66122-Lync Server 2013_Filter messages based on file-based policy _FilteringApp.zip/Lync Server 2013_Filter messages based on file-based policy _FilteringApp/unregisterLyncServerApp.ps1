remove-csServerApplication -identity "service:registrar:<lync-server-fqdn>/FilteringApp"

del 'C:\Program Files\Microsoft Lync server 2013\server\Core\Filter.am'
del 'C:\Program Files\Microsoft Lync server 2013\server\Core\Policy.txt'

invoke-csManagementStoreReplication

